-- SmartMove PL/SQL (Member 2) - Oracle implementation
-- Run in Oracle SQL Developer connected as SmartMove schema.
-- Tables assumed from Member 1: VEHICLE DRIVER ROUTE PASSENGER TRIP BOOKING PAYMENT MAINTENANCE FEEDBACK

-- 1) Booking procedure (called by PHP app instead of duplicating logic)
CREATE OR REPLACE PROCEDURE sp_book_ticket(
  p_passenger_id IN NUMBER, p_trip_id IN NUMBER, p_seat IN NUMBER, p_fare IN NUMBER,
  p_booking_id OUT NUMBER) AS
  v_cap VEHICLE.Capacity%TYPE; v_cnt NUMBER;
  e_seat_taken EXCEPTION; e_no_cap EXCEPTION;
BEGIN
  SELECT Capacity INTO v_cap FROM VEHICLE WHERE VehicleID =
    (SELECT VehicleID FROM TRIP WHERE TripID = p_trip_id);
  IF p_seat < 1 OR p_seat > v_cap THEN RAISE e_no_cap; END IF;
  SELECT COUNT(*) INTO v_cnt FROM BOOKING WHERE TripID = p_trip_id AND SeatNumber = p_seat
    AND BookingStatus = 'Confirmed';
  IF v_cnt > 0 THEN RAISE e_seat_taken; END IF;
  INSERT INTO BOOKING(PassengerID,TripID,SeatNumber,Fare,BookingStatus)
  VALUES(p_passenger_id,p_trip_id,p_seat,p_fare,'Confirmed') RETURNING BookingID INTO p_booking_id;
  COMMIT;
EXCEPTION
  WHEN e_seat_taken THEN RAISE_APPLICATION_ERROR(-20001,'Booking failed: seat already booked.');
  WHEN e_no_cap THEN RAISE_APPLICATION_ERROR(-20002,'Booking failed: invalid seat for vehicle capacity.');
  WHEN NO_DATA_FOUND THEN RAISE_APPLICATION_ERROR(-20003,'Booking failed: invalid passenger or trip.');
  WHEN DUP_VAL_ON_INDEX THEN RAISE_APPLICATION_ERROR(-20001,'Booking failed: seat already booked.');
  WHEN OTHERS THEN ROLLBACK; RAISE;
END;/

-- 2) Payment procedure
CREATE OR REPLACE PROCEDURE sp_record_payment(
  p_booking_id IN NUMBER, p_amount IN NUMBER, p_method IN VARCHAR2) AS
  v_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_cnt FROM PAYMENT WHERE BookingID = p_booking_id;
  IF v_cnt > 0 THEN RAISE_APPLICATION_ERROR(-20010,'Payment already recorded for booking.'); END IF;
  INSERT INTO PAYMENT(BookingID,Amount,PaymentMethod,PaymentStatus)
  VALUES(p_booking_id,p_amount,p_method,'Paid');
  COMMIT;
EXCEPTION WHEN OTHERS THEN ROLLBACK; RAISE; END;/

-- 3) Feedback procedure
CREATE OR REPLACE PROCEDURE sp_add_feedback(
  p_passenger_id IN NUMBER, p_trip_id IN NUMBER, p_rating IN NUMBER, p_comment IN VARCHAR2) AS
BEGIN
  IF p_rating NOT BETWEEN 1 AND 5 THEN RAISE_APPLICATION_ERROR(-20020,'Rating must be 1-5.'); END IF;
  INSERT INTO FEEDBACK(PassengerID,TripID,Rating,CommentText)
  VALUES(p_passenger_id,p_trip_id,p_rating,p_comment);
  COMMIT;
EXCEPTION WHEN DUP_VAL_ON_INDEX THEN RAISE_APPLICATION_ERROR(-20021,'Feedback already given for this trip.');
WHEN OTHERS THEN ROLLBACK; RAISE; END;/

-- 4) Functions
CREATE OR REPLACE FUNCTION fn_trip_revenue(p_trip_id IN NUMBER) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(Fare),0) INTO v_sum FROM BOOKING WHERE TripID=p_trip_id AND BookingStatus='Confirmed'; RETURN v_sum; END;/
CREATE OR REPLACE FUNCTION fn_revenue_period(p_from IN DATE, p_to IN DATE) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(Amount),0) INTO v_sum FROM PAYMENT WHERE PaymentDate BETWEEN p_from AND p_to AND PaymentStatus='Paid'; RETURN v_sum; END;/

-- 5) Triggers
CREATE OR REPLACE TRIGGER trg_booking_fare_check BEFORE INSERT OR UPDATE ON BOOKING
FOR EACH ROW BEGIN IF :NEW.Fare < 0 THEN RAISE_APPLICATION_ERROR(-20101,'Fare cannot be negative.'); END IF;
IF :NEW.SeatNumber < 1 THEN RAISE_APPLICATION_ERROR(-20102,'Seat must be positive.'); END IF; END;/
CREATE OR REPLACE TRIGGER trg_payment_amount_check BEFORE INSERT OR UPDATE ON PAYMENT
FOR EACH ROW BEGIN IF :NEW.Amount < 0 THEN RAISE_APPLICATION_ERROR(-20103,'Amount cannot be negative.'); END IF; END;/

-- 6) REPORTS (5) as views/cursors the app displays
-- R1 most frequent routes
CREATE OR REPLACE VIEW vw_report_route_usage AS
SELECT r.RouteID, r.StartLocation||' -> '||r.EndLocation AS route, COUNT(b.BookingID) AS bookings,
NVL(SUM(b.Fare),0) AS revenue FROM ROUTE r LEFT JOIN TRIP t ON t.RouteID=r.RouteID
LEFT JOIN BOOKING b ON b.TripID=t.TripID AND b.BookingStatus='Confirmed'
GROUP BY r.RouteID, r.StartLocation, r.EndLocation ORDER BY bookings DESC;
-- R2 revenue in period: SELECT fn_revenue_period(DATE'2026-01-01',DATE'2026-01-31') FROM DUAL;
-- R3 passenger history:
CREATE OR REPLACE VIEW vw_report_passenger_history AS
SELECT p.PassengerID, p.FirstName||' '||p.LastName AS passenger, t.TripID, r.StartLocation||' -> '||r.EndLocation AS route,
t.TripDate, b.SeatNumber, b.Fare FROM PASSENGER p JOIN BOOKING b ON b.PassengerID=p.PassengerID
JOIN TRIP t ON t.TripID=b.TripID JOIN ROUTE r ON r.RouteID=t.RouteID ORDER BY p.PassengerID, t.TripDate;
-- R4 vehicles due maintenance (next date within 30 days or overdue):
CREATE OR REPLACE VIEW vw_report_maintenance_due AS
SELECT v.VehicleID, v.RegistrationNo, m.NextMaintenanceDate, m.MaintenanceType, m.MaintenanceStatus
FROM VEHICLE v JOIN MAINTENANCE m ON m.VehicleID=v.VehicleID
WHERE m.NextMaintenanceDate <= SYSDATE + 30 ORDER BY m.NextMaintenanceDate;
-- R5 driver performance:
CREATE OR REPLACE VIEW vw_report_driver_perf AS
SELECT d.DriverID, d.FirstName||' '||d.LastName AS driver, COUNT(t.TripID) AS trips,
NVL(AVG(f.Rating),0) AS avg_rating FROM DRIVER d LEFT JOIN TRIP t ON t.DriverID=d.DriverID
LEFT JOIN FEEDBACK f ON f.TripID=t.TripID GROUP BY d.DriverID,d.FirstName,d.LastName ORDER BY trips DESC;

CREATE OR REPLACE PROCEDURE sp_add_trip(p_route_id IN NUMBER, p_vehicle_id IN NUMBER, p_driver_id IN NUMBER, p_date IN DATE) AS
BEGIN
  INSERT INTO TRIP(RouteID,VehicleID,DriverID,TripDate,Status) VALUES(p_route_id,p_vehicle_id,p_driver_id,p_date,'Scheduled');
  COMMIT;
EXCEPTION WHEN OTHERS THEN ROLLBACK; RAISE; END;/

CREATE OR REPLACE PROCEDURE sp_schedule_maintenance(p_vehicle_id IN NUMBER, p_date IN DATE, p_next IN DATE, p_type IN VARCHAR2) AS
BEGIN
  IF p_next < p_date THEN RAISE_APPLICATION_ERROR(-20104,'Next date must be >= maintenance date.'); END IF;
  INSERT INTO MAINTENANCE(VehicleID,MaintenanceDate,NextMaintenanceDate,MaintenanceType,MaintenanceStatus)
  VALUES(p_vehicle_id,p_date,p_next,p_type,'Scheduled');
  COMMIT;
EXCEPTION WHEN OTHERS THEN ROLLBACK; RAISE; END;/

CREATE OR REPLACE FUNCTION fn_route_revenue(p_route_id IN NUMBER) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(b.Fare),0) INTO v_sum FROM BOOKING b JOIN TRIP t ON t.TripID=b.TripID WHERE t.RouteID=p_route_id AND b.BookingStatus='Confirmed'; RETURN v_sum; END;/
CREATE OR REPLACE FUNCTION fn_passenger_total_spent(p_pass_id IN NUMBER) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(Fare),0) INTO v_sum FROM BOOKING WHERE PassengerID=p_pass_id AND BookingStatus='Confirmed'; RETURN v_sum; END;/
CREATE OR REPLACE FUNCTION fn_driver_avg_rating(p_driver_id IN NUMBER) RETURN NUMBER AS v_avg NUMBER:=0;
BEGIN SELECT NVL(AVG(f.Rating),0) INTO v_avg FROM FEEDBACK f JOIN TRIP t ON t.TripID=f.TripID WHERE t.DriverID=p_driver_id; RETURN v_avg; END;/
CREATE OR REPLACE FUNCTION fn_overdue_count RETURN NUMBER AS v_n NUMBER:=0;
BEGIN SELECT COUNT(*) INTO v_n FROM MAINTENANCE WHERE NextMaintenanceDate < SYSDATE AND MaintenanceStatus <> 'Completed'; RETURN v_n; END;/

CREATE OR REPLACE TRIGGER trg_maint_dates_check BEFORE INSERT OR UPDATE ON MAINTENANCE
FOR EACH ROW BEGIN IF :NEW.NextMaintenanceDate < :NEW.MaintenanceDate THEN RAISE_APPLICATION_ERROR(-20104,'Next date must be >= maintenance date.'); END IF; END;/
CREATE OR REPLACE TRIGGER trg_feedback_rating_check BEFORE INSERT OR UPDATE ON FEEDBACK
FOR EACH ROW BEGIN IF :NEW.Rating NOT BETWEEN 1 AND 5 THEN RAISE_APPLICATION_ERROR(-20020,'Rating must be 1-5.'); END IF; END;/
CREATE OR REPLACE TRIGGER trg_route_delete_guard BEFORE DELETE ON ROUTE
FOR EACH ROW DECLARE v_n NUMBER; BEGIN SELECT COUNT(*) INTO v_n FROM TRIP WHERE RouteID=:OLD.RouteID; IF v_n > 0 THEN RAISE_APPLICATION_ERROR(-20105,'Cannot delete route with scheduled trips.'); END IF; END;/

CREATE OR REPLACE PROCEDURE sp_cursor_report_demo AS
  CURSOR c_route IS SELECT r.RouteID, COUNT(b.BookingID) cnt FROM ROUTE r LEFT JOIN TRIP t ON t.RouteID=r.RouteID LEFT JOIN BOOKING b ON b.TripID=t.TripID GROUP BY r.RouteID;
  CURSOR c_pay IS SELECT PaymentMethod, COUNT(*) cnt, SUM(Amount) total FROM PAYMENT WHERE PaymentStatus='Paid' GROUP BY PaymentMethod;
  CURSOR c_due IS SELECT VehicleID, NextMaintenanceDate FROM MAINTENANCE WHERE NextMaintenanceDate <= SYSDATE + 30 ORDER BY NextMaintenanceDate;
  v_r c_route%ROWTYPE; v_p c_pay%ROWTYPE; v_m c_due%ROWTYPE;
BEGIN
  OPEN c_route; LOOP FETCH c_route INTO v_r; EXIT WHEN c_route%NOTFOUND; NULL; END LOOP; CLOSE c_route;
  OPEN c_pay; LOOP FETCH c_pay INTO v_p; EXIT WHEN c_pay%NOTFOUND; NULL; END LOOP; CLOSE c_pay;
  OPEN c_due; LOOP FETCH c_due INTO v_m; EXIT WHEN c_due%NOTFOUND; NULL; END LOOP; CLOSE c_due;
EXCEPTION WHEN OTHERS THEN IF c_route%ISOPEN THEN CLOSE c_route; END IF; IF c_pay%ISOPEN THEN CLOSE c_pay; END IF; IF c_due%ISOPEN THEN CLOSE c_due; END IF; RAISE; END;/
