-- SmartMove PL/SQL split file - run all.sql for the complete build.

CREATE OR REPLACE FUNCTION fn_trip_revenue(p_trip_id IN NUMBER) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(Fare),0) INTO v_sum FROM BOOKING WHERE TripID=p_trip_id AND BookingStatus='Confirmed'; RETURN v_sum; END;/

CREATE OR REPLACE FUNCTION fn_revenue_period(p_from IN DATE, p_to IN DATE) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(Amount),0) INTO v_sum FROM PAYMENT WHERE PaymentDate BETWEEN p_from AND p_to AND PaymentStatus='Paid'; RETURN v_sum; END;/

-- 5) Triggers

CREATE OR REPLACE FUNCTION fn_route_revenue(p_route_id IN NUMBER) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(b.Fare),0) INTO v_sum FROM BOOKING b JOIN TRIP t ON t.TripID=b.TripID WHERE t.RouteID=p_route_id AND b.BookingStatus='Confirmed'; RETURN v_sum; END;/

CREATE OR REPLACE FUNCTION fn_passenger_total_spent(p_pass_id IN NUMBER) RETURN NUMBER AS v_sum NUMBER:=0;
BEGIN SELECT NVL(SUM(Fare),0) INTO v_sum FROM BOOKING WHERE PassengerID=p_pass_id AND BookingStatus='Confirmed'; RETURN v_sum; END;/

CREATE OR REPLACE FUNCTION fn_driver_avg_rating(p_driver_id IN NUMBER) RETURN NUMBER AS v_avg NUMBER:=0;
BEGIN SELECT NVL(AVG(f.Rating),0) INTO v_avg FROM FEEDBACK f JOIN TRIP t ON t.TripID=f.TripID WHERE t.DriverID=p_driver_id; RETURN v_avg; END;/

CREATE OR REPLACE FUNCTION fn_overdue_count RETURN NUMBER AS v_n NUMBER:=0;
BEGIN SELECT COUNT(*) INTO v_n FROM MAINTENANCE WHERE NextMaintenanceDate < SYSDATE AND MaintenanceStatus <> 'Completed'; RETURN v_n; END;/