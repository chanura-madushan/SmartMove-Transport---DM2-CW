-- SmartMove PL/SQL split file - run all.sql for the complete build.

CREATE OR REPLACE VIEW vw_report_route_usage AS
SELECT r.RouteID, r.StartLocation||' -> '||r.EndLocation AS route, COUNT(b.BookingID) AS bookings,
NVL(SUM(b.Fare),0) AS revenue FROM ROUTE r LEFT JOIN TRIP t ON t.RouteID=r.RouteID
LEFT JOIN BOOKING b ON b.TripID=t.TripID AND b.BookingStatus='Confirmed'
GROUP BY r.RouteID, r.StartLocation, r.EndLocation ORDER BY bookings DESC;
-- R2 revenue in period: SELECT fn_revenue_period(DATE'2026-01-01',DATE'2026-01-31') FROM DUAL;
-- R3 passenger history:

CREATE OR REPLACE VIEW vw_report_passenger_history AS
SELECT p.PassengerID, p.FirstName||' '||p.LastName AS passenger, t.TripID, r.StartLocation||' -> '||r.EndLocation AS route,
t.TripDate, b.SeatNumber, b.Fare FROM PASSENGER p JOIN BOOKING b ON b.PassengerID=p.PassengerID
JOIN TRIP t ON t.TripID=b.TripID JOIN ROUTE r ON r.RouteID=t.RouteID ORDER BY p.PassengerID, t.TripDate;
-- R4 vehicles due maintenance (next date within 30 days or overdue):

CREATE OR REPLACE VIEW vw_report_maintenance_due AS
SELECT v.VehicleID, v.RegistrationNo, m.NextMaintenanceDate, m.MaintenanceType, m.MaintenanceStatus
FROM VEHICLE v JOIN MAINTENANCE m ON m.VehicleID=v.VehicleID
WHERE m.NextMaintenanceDate <= SYSDATE + 30 ORDER BY m.NextMaintenanceDate;
-- R5 driver performance:

CREATE OR REPLACE VIEW vw_report_driver_perf AS
SELECT d.DriverID, d.FirstName||' '||d.LastName AS driver, COUNT(t.TripID) AS trips,
NVL(AVG(f.Rating),0) AS avg_rating FROM DRIVER d LEFT JOIN TRIP t ON t.DriverID=d.DriverID
LEFT JOIN FEEDBACK f ON f.TripID=t.TripID GROUP BY d.DriverID,d.FirstName,d.LastName ORDER BY trips DESC;