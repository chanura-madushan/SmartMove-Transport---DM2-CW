-- SmartMove PL/SQL split file - run all.sql for the complete build.

CREATE OR REPLACE PROCEDURE sp_book_ticket(
  p_passenger_id IN NUMBER, p_trip_id IN NUMBER, p_seat IN NUMBER, p_fare IN NUMBER,
  p_booking_id OUT NUMBER) AS
  v_cap VEHICLE.Capacity%TYPE; v_cnt NUMBER;
  e_seat_taken EXCEPTION; e_no_cap EXCEPTION;
BEGIN
  SELECT Capacity INTO v_cap FROM VEHICLE WHERE VehicleID =
    (SELECT VehicleID FROM TRIP WHERE TripID = p_trip_id);
  IF p_seat < 1 OR p_seat > v_cap THEN RAISE e_no_cap; END IF;
  SELECT COUNT(*) INTO v_cnt FROM BOOKING WHERE TripID = p_trip_id AND SeatNumber = p_seat
    AND BookingStatus = 'Confirmed';
  IF v_cnt > 0 THEN RAISE e_seat_taken; END IF;
  INSERT INTO BOOKING(PassengerID,TripID,SeatNumber,Fare,BookingStatus)
  VALUES(p_passenger_id,p_trip_id,p_seat,p_fare,'Confirmed') RETURNING BookingID INTO p_booking_id;
  COMMIT;
EXCEPTION
  WHEN e_seat_taken THEN RAISE_APPLICATION_ERROR(-20001,'Booking failed: seat already booked.');
  WHEN e_no_cap THEN RAISE_APPLICATION_ERROR(-20002,'Booking failed: invalid seat for vehicle capacity.');
  WHEN NO_DATA_FOUND THEN RAISE_APPLICATION_ERROR(-20003,'Booking failed: invalid passenger or trip.');
  WHEN DUP_VAL_ON_INDEX THEN RAISE_APPLICATION_ERROR(-20001,'Booking failed: seat already booked.');
  WHEN OTHERS THEN ROLLBACK; RAISE;
END;/

-- 2) Payment procedure

CREATE OR REPLACE PROCEDURE sp_record_payment(
  p_booking_id IN NUMBER, p_amount IN NUMBER, p_method IN VARCHAR2) AS
  v_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_cnt FROM PAYMENT WHERE BookingID = p_booking_id;
  IF v_cnt > 0 THEN RAISE_APPLICATION_ERROR(-20010,'Payment already recorded for booking.'); END IF;
  INSERT INTO PAYMENT(BookingID,Amount,PaymentMethod,PaymentStatus)
  VALUES(p_booking_id,p_amount,p_method,'Paid');
  COMMIT;
EXCEPTION WHEN OTHERS THEN ROLLBACK; RAISE; END;/

-- 3) Feedback procedure

CREATE OR REPLACE PROCEDURE sp_add_feedback(
  p_passenger_id IN NUMBER, p_trip_id IN NUMBER, p_rating IN NUMBER, p_comment IN VARCHAR2) AS
BEGIN
  IF p_rating NOT BETWEEN 1 AND 5 THEN RAISE_APPLICATION_ERROR(-20020,'Rating must be 1-5.'); END IF;
  INSERT INTO FEEDBACK(PassengerID,TripID,Rating,CommentText)
  VALUES(p_passenger_id,p_trip_id,p_rating,p_comment);
  COMMIT;
EXCEPTION WHEN DUP_VAL_ON_INDEX THEN RAISE_APPLICATION_ERROR(-20021,'Feedback already given for this trip.');
WHEN OTHERS THEN ROLLBACK; RAISE; END;/

-- 4) Functions

CREATE OR REPLACE PROCEDURE sp_add_trip(p_route_id IN NUMBER, p_vehicle_id IN NUMBER, p_driver_id IN NUMBER, p_date IN DATE) AS
BEGIN
  INSERT INTO TRIP(RouteID,VehicleID,DriverID,TripDate,Status) VALUES(p_route_id,p_vehicle_id,p_driver_id,p_date,'Scheduled');
  COMMIT;
EXCEPTION WHEN OTHERS THEN ROLLBACK; RAISE; END;/

CREATE OR REPLACE PROCEDURE sp_schedule_maintenance(p_vehicle_id IN NUMBER, p_date IN DATE, p_next IN DATE, p_type IN VARCHAR2) AS
BEGIN
  IF p_next < p_date THEN RAISE_APPLICATION_ERROR(-20104,'Next date must be >= maintenance date.'); END IF;
  INSERT INTO MAINTENANCE(VehicleID,MaintenanceDate,NextMaintenanceDate,MaintenanceType,MaintenanceStatus)
  VALUES(p_vehicle_id,p_date,p_next,p_type,'Scheduled');
  COMMIT;
EXCEPTION WHEN OTHERS THEN ROLLBACK; RAISE; END;/

CREATE OR REPLACE PROCEDURE sp_cursor_report_demo AS
  CURSOR c_route IS SELECT r.RouteID, COUNT(b.BookingID) cnt FROM ROUTE r LEFT JOIN TRIP t ON t.RouteID=r.RouteID LEFT JOIN BOOKING b ON b.TripID=t.TripID GROUP BY r.RouteID;
  CURSOR c_pay IS SELECT PaymentMethod, COUNT(*) cnt, SUM(Amount) total FROM PAYMENT WHERE PaymentStatus='Paid' GROUP BY PaymentMethod;
  CURSOR c_due IS SELECT VehicleID, NextMaintenanceDate FROM MAINTENANCE WHERE NextMaintenanceDate <= SYSDATE + 30 ORDER BY NextMaintenanceDate;
  v_r c_route%ROWTYPE; v_p c_pay%ROWTYPE; v_m c_due%ROWTYPE;
BEGIN
  OPEN c_route; LOOP FETCH c_route INTO v_r; EXIT WHEN c_route%NOTFOUND; NULL; END LOOP; CLOSE c_route;
  OPEN c_pay; LOOP FETCH c_pay INTO v_p; EXIT WHEN c_pay%NOTFOUND; NULL; END LOOP; CLOSE c_pay;
  OPEN c_due; LOOP FETCH c_due INTO v_m; EXIT WHEN c_due%NOTFOUND; NULL; END LOOP; CLOSE c_due;
EXCEPTION WHEN OTHERS THEN IF c_route%ISOPEN THEN CLOSE c_route; END IF; IF c_pay%ISOPEN THEN CLOSE c_pay; END IF; IF c_due%ISOPEN THEN CLOSE c_due; END IF; RAISE; END;/