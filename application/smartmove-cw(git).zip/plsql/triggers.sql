-- SmartMove PL/SQL split file - run all.sql for the complete build.

CREATE OR REPLACE TRIGGER trg_booking_fare_check BEFORE INSERT OR UPDATE ON BOOKING
FOR EACH ROW BEGIN IF :NEW.Fare < 0 THEN RAISE_APPLICATION_ERROR(-20101,'Fare cannot be negative.'); END IF;
IF :NEW.SeatNumber < 1 THEN RAISE_APPLICATION_ERROR(-20102,'Seat must be positive.'); END IF; END;/

CREATE OR REPLACE TRIGGER trg_payment_amount_check BEFORE INSERT OR UPDATE ON PAYMENT
FOR EACH ROW BEGIN IF :NEW.Amount < 0 THEN RAISE_APPLICATION_ERROR(-20103,'Amount cannot be negative.'); END IF; END;/

-- 6) REPORTS (5) as views/cursors the app displays
-- R1 most frequent routes

CREATE OR REPLACE TRIGGER trg_maint_dates_check BEFORE INSERT OR UPDATE ON MAINTENANCE
FOR EACH ROW BEGIN IF :NEW.NextMaintenanceDate < :NEW.MaintenanceDate THEN RAISE_APPLICATION_ERROR(-20104,'Next date must be >= maintenance date.'); END IF; END;/

CREATE OR REPLACE TRIGGER trg_feedback_rating_check BEFORE INSERT OR UPDATE ON FEEDBACK
FOR EACH ROW BEGIN IF :NEW.Rating NOT BETWEEN 1 AND 5 THEN RAISE_APPLICATION_ERROR(-20020,'Rating must be 1-5.'); END IF; END;/

CREATE OR REPLACE TRIGGER trg_route_delete_guard BEFORE DELETE ON ROUTE
FOR EACH ROW DECLARE v_n NUMBER; BEGIN SELECT COUNT(*) INTO v_n FROM TRIP WHERE RouteID=:OLD.RouteID; IF v_n > 0 THEN RAISE_APPLICATION_ERROR(-20105,'Cannot delete route with scheduled trips.'); END IF; END;/