(function () {
  var O = window.SM_ORACLE, M = window.SM_MONGO;
  var PRIMARY = { r1: "v1", r2: "v2", r3: "v3", r4: "v4", r5: "v5" };
  var OP_HOME = { v1: "r1", "c-routes": "r1", "f-route": "r1", "p-route": "r1", "t-route": "r1", v2: "r2", "p-pay": "r2", "f-rev": "r2", "f-trip": "r2", "t-payamt": "r2", "c-paymethod": "r2", v3: "r3", "p-book": "r3", "t-seat": "r3", "t-fare": "r3", "f-passtotal": "r3", "c-passbook": "r3", v4: "r4", "p-maint": "r4", "t-maintdate": "r4", "c-maintdue": "r4", "f-maintover": "r4", v5: "r5", "p-fb": "r5", "f-drvavg": "r5", "t-fbrate": "r5", "c-drvperf": "r5" };
  var activeSec = "r1";
  function revDefault() {
    return O.payments.filter(function (p) { return p.status === "Paid"; })
      .reduce(function (a, p) { return a + p.amt; }, 0);
  }
  var OPS = [
    { id: "v1", kind: "view", keys: "route usage frequent all r1", title: "route usage (R1)", run: function () {
      var rows = O.routes.map(function (r) {
        var ts = O.trips.filter(function (t) { return t.route === r.id; }).map(function (t) { return t.id; });
        var bs = O.bookings.filter(function (b) { return ts.indexOf(b.trip) > -1 && b.status === "Confirmed"; });
        return [esc(r.from + " → " + r.to), bs.length, bs.reduce(function (a, b) { return a + b.fare; }, 0)];
      }).sort(function (a, b) { return b[1] - a[1]; });
      return "<p>VIEW vw_report_route_usage — " + rows.length + " routes.</p>" + tbl(["Route", "Bookings", "Revenue"], rows);
    } },
    { id: "v2", kind: "view", keys: "revenue period money payments all r2", title: "revenue in period (R2)", run: function () {
      var f = (document.getElementById("wFrom-r2") || {}).value || "2026-01-01";
      var t = (document.getElementById("wTo-r2") || {}).value || "2026-01-31";
      var pays = O.payments.filter(function (p) { return p.status === "Paid" && p.date >= f && p.date <= t; });
      return "From <input id='wFrom-r2' type='date' value='" + f + "'> To <input id='wTo-r2' type='date' value='" + t + "'> "
        + "<button class='btn' data-apply='v2'>Apply</button>"
        + "<p>Revenue " + f + " → " + t + ": <b>Rs " + pays.reduce(function (a, p) { return a + p.amt; }, 0).toLocaleString() + "</b> — " + pays.length + " payments.</p>"
        + tbl(["ID", "Booking (seat)", "Date", "Amt", "Method"], pays.map(function (p) {
          var b = O.bookings.filter(function (x) { return x.id === p.booking; })[0] || {};
          return [p.id, "#" + p.booking + " • seat " + (b.seat == null ? "—" : b.seat), p.date, p.amt, p.method];
        }));
    } },
    { id: "v3", kind: "view", keys: "passenger travel history trips all r3", title: "passenger history (R3)", run: function () {
      var sel = document.getElementById("wPass-r3");
      var pid = (sel && sel.value) || String(O.passengers[0].id);
      var opts = O.passengers.map(function (p) { return "<option value='" + p.id + "'" + (String(p.id) === String(pid) ? " selected" : "") + ">" + esc(p.fn + " " + p.ln) + "</option>"; }).join("");
      var rows = O.bookings.filter(function (b) { return b.pass == pid; }).map(function (b) {
        var t = O.trips.filter(function (x) { return x.id === b.trip; })[0] || {};
        return [esc(pName(b.pass)), "#" + b.trip, esc(rName(t.route)), b.date, b.seat, b.fare, b.status];
      });
      return "<select id='wPass-r3'>" + opts + "</select> <button class='btn' data-apply='v3'>Load</button>"
        + tbl(["Passenger", "Trip", "Route", "Date", "Seat", "Fare", "Status"], rows.length ? rows : [["—", "—", "No bookings for this passenger yet", "", "", "", ""]]);
    } },
    { id: "v4", kind: "view", keys: "maintenance due vehicles all r4", title: "maintenance due (R4)", run: function () {
      return "<p>VIEW vw_report_maintenance_due — " + O.maintenance.length + " records.</p>"
        + tbl(["Vehicle", "Next due", "Type", "Status"], O.maintenance.map(function (m) { return [esc(vName(m.vehicle)), m.next, esc(m.type), m.status]; }));
    } },
    { id: "v5", kind: "view", keys: "driver trip performance rating all r5", title: "driver performance (R5)", run: function () {
      var sel = document.getElementById("wRate-r5");
      var minR = +((sel && sel.value) || 0);
      function opt(v) { return "<option value='" + v + "'" + (minR === v ? " selected" : "") + ">" + (v === 0 ? "any" : v + "+") + "</option>"; }
      var rows = O.drivers.map(function (d) {
        var ts = O.trips.filter(function (t) { return t.driver === d.id; });
        var fb = O.feedback.filter(function (f) { return ts.some(function (t) { return t.id === f.trip; }); });
        var avg = fb.length ? fb.reduce(function (a, f) { return a + f.rating; }, 0) / fb.length : 0;
        return { d: d, trips: ts.length, avg: avg };
      }).filter(function (p) { return p.avg >= minR; }).sort(function (a, b) { return b.trips - a.trips; })
        .map(function (p) { return [esc(p.d.fn + " " + p.d.ln), p.trips, p.avg ? p.avg.toFixed(1) : "—"]; });
      return "Min rating <select id='wRate-r5'>" + opt(0) + opt(3) + opt(4) + opt(5) + "</select> <button class='btn' data-apply='v5'>Apply</button>"
        + tbl(["Driver", "Trips", "Avg rating"], rows);
    } },
    { id: "p-book", kind: "procedure", keys: "sp_book_ticket booking seats reserve", title: "sp_book_ticket (demo booking)", run: function () {
      var t = O.trips[1], cap = tripCap(t);
      var taken = tripTaken(t.id), s = 1;
      while (taken.indexOf(s) > -1 && s <= cap) s++;
      try {
        var id = spBook(1, t.id, s, 300);
        if (window.refreshAll) refreshAll();
        return "BEGIN sp_book_ticket(1, " + t.id + ", " + s + ", 300); END;<br>→ SUCCESS booking_id=" + id + " (seat " + s + " reserved on trip #" + t.id + ")";
      } catch (e) { return "BEGIN sp_book_ticket … END;<br>→ ORA-20001: " + esc(e); }
    } },
    { id: "p-pay", kind: "procedure", keys: "sp_record_payment pay money", title: "sp_record_payment (first unpaid)", run: function () {
      var b = O.bookings.filter(function (x) { return x.status === "Confirmed" && !O.payments.some(function (p) { return p.booking === x.id; }); })[0];
      if (!b) return "→ nothing to do: every confirmed booking already has a payment.";
      O.payments.push({ id: Math.max.apply(null, O.payments.map(function (p) { return p.id; })) + 1, booking: b.id, date: new Date().toISOString().slice(0, 10), amt: b.fare, method: "Card", status: "Paid" });
      if (window.refreshAll) refreshAll();
      return "BEGIN sp_record_payment(" + b.id + ", " + b.fare + ", Card); END;<br>→ SUCCESS payment recorded for booking #" + b.id + " (seat " + b.seat + ")";
    } },
    { id: "p-fb", kind: "procedure", keys: "sp_add_feedback rating stars", title: "sp_add_feedback (demo)", run: function () {
      var pair = null;
      outer: for (var pi = 0; pi < O.passengers.length; pi++) for (var ti = 0; ti < O.trips.length; ti++) {
        var p = O.passengers[pi].id, t = O.trips[ti].id;
        if (!O.feedback.some(function (f) { return f.pass === p && f.trip === t; })) { pair = [p, t]; break outer; }
      }
      if (!pair) return "→ every passenger×trip pair already has feedback.";
      O.feedback.push({ id: Math.max.apply(null, O.feedback.map(function (f) { return f.id; })) + 1, pass: pair[0], trip: pair[1], rating: 5, text: "Demo via smart bar", date: new Date().toISOString().slice(0, 10) });
      if (window.refreshAll) refreshAll();
      return "BEGIN sp_add_feedback(" + pair[0] + ", " + pair[1] + ", 5, …); END;<br>→ SUCCESS feedback saved (Oracle FEEDBACK)";
    } },
    { id: "f-rev", kind: "function", keys: "fn_revenue_period total money", title: "fn_revenue_period → total", run: function () {
      return "SELECT fn_revenue_period('2026-01-01','2026-01-31') FROM DUAL;<br>→ Rs " + revDefault().toLocaleString();
    } },
    { id: "f-trip", kind: "function", keys: "fn_trip_revenue trip money", title: "fn_trip_revenue(trip 1)", run: function () {
      var s = O.bookings.filter(function (b) { return b.trip === 1 && b.status === "Confirmed"; }).reduce(function (a, b) { return a + b.fare; }, 0);
      return "SELECT fn_trip_revenue(1) FROM DUAL;<br>→ trip 1 revenue = Rs " + s;
    } },
    { id: "t-fare", kind: "trigger", keys: "trg_booking_fare_check negative fare block", title: "trigger: negative fare blocked", run: function () {
      return "INSERT INTO BOOKING … Fare=-50;<br>→ ORA-20101: Fare cannot be negative. (trg_booking_fare_check blocked it)";
    } },
    { id: "t-seat", kind: "trigger", keys: "seat taken duplicate unique constraint", title: "trigger: duplicate seat blocked", run: function () {
      try { spBook(1, 1, 1, 250); return "→ unexpectedly inserted (seat 1 on trip 1 was free — try again to see the block)."; }
      catch (e) { return "INSERT INTO BOOKING … (TripID=1, Seat=1);<br>→ ORA-20001: " + esc(e) + " (UQ_BOOKING_SEAT + procedure guard)";
      }
    } },
    { id: "f-route", kind: "function", keys: "fn_route_revenue route money total r1", title: "fn_route_revenue (busiest route)", run: function () {
      var best = null, bestN = -1;
      O.routes.forEach(function (r) {
        var ts = O.trips.filter(function (t) { return t.route === r.id; }).map(function (t) { return t.id; });
        var n = O.bookings.filter(function (b) { return ts.indexOf(b.trip) > -1 && b.status === "Confirmed"; }).length;
        if (n > bestN) { bestN = n; best = r; }
      });
      var ts2 = O.trips.filter(function (t) { return t.route === best.id; }).map(function (t) { return t.id; });
      var rev = O.bookings.filter(function (b) { return ts2.indexOf(b.trip) > -1 && b.status === "Confirmed"; }).reduce(function (a, b) { return a + b.fare; }, 0);
      return "SELECT fn_route_revenue(" + best.id + ") FROM DUAL;<br>→ " + esc(best.from + " → " + best.to) + ": <b>" + bestN + " bookings, Rs " + rev.toLocaleString() + "</b>";
    } },
    { id: "p-route", kind: "procedure", keys: "sp_add_trip route schedule procedure r1", title: "sp_add_trip (on busiest route)", run: function () {
      var best = null, bestN = -1;
      O.routes.forEach(function (r) {
        var n = O.trips.filter(function (t) { return t.route === r.id; }).length;
        if (n > bestN) { bestN = n; best = r; }
      });
      var id = Math.max.apply(null, O.trips.map(function (t) { return t.id; })) + 1;
      O.trips.push({ id: id, vehicle: O.vehicles[0].id, driver: O.drivers[0].id, route: best.id, date: "2026-03-01", dep: "09:00", arr: "", status: "Scheduled" });
      if (window.refreshAll) refreshAll();
      return "BEGIN sp_add_trip(route_id =&gt; " + best.id + "); END;<br>→ SUCCESS trip #" + id + " scheduled on " + esc(best.from + " → " + best.to);
    } },
    { id: "t-route", kind: "trigger", keys: "route delete guard trigger fk exception r1", title: "trigger: route delete blocked", run: function () {
      var r = O.routes.filter(function (x) { return O.trips.some(function (t) { return t.route === x.id; }); })[0];
      return "DELETE FROM ROUTE WHERE RouteID=" + (r ? r.id : "?") + ";<br>→ ORA-02292: child record found (TRIP references it — trigger/FK blocked it)";
    } },
    { id: "t-payamt", kind: "trigger", keys: "trg_payment_amount_check negative amount block exception r2", title: "trigger: negative amount blocked", run: function () {
      return "INSERT INTO PAYMENT … Amount=-100;<br>→ ORA-20103: Amount cannot be negative. (trg_payment_amount_check blocked it)";
    } },
    { id: "c-paymethod", kind: "cursor", keys: "cursor payments per method fetch loop r2", title: "cursor: revenue per method", run: function () {
      var methods = {};
      O.payments.filter(function (p) { return p.status === "Paid"; }).forEach(function (p) {
        methods[p.method] = methods[p.method] || { n: 0, s: 0 };
        methods[p.method].n++; methods[p.method].s += p.amt;
      });
      var lines = Object.keys(methods).map(function (m) { return "FETCH → " + esc(m) + " : " + methods[m].n + " payment(s), Rs " + methods[m].s.toLocaleString(); });
      return "CURSOR c IS SELECT PaymentMethod, COUNT(*), SUM(Amount) …<br>" + (lines.join("<br>") || "→ no paid payments yet") + "<br>CLOSE c;";
    } },
    { id: "f-passtotal", kind: "function", keys: "fn_passenger_total_spent passenger money total r3", title: "fn_passenger_total_spent", run: function () {
      var p = O.passengers[0];
      var s = O.bookings.filter(function (b) { return b.pass === p.id && b.status === "Confirmed"; }).reduce(function (a, b) { return a + b.fare; }, 0);
      return "SELECT fn_passenger_total_spent(" + p.id + ") FROM DUAL;<br>→ " + esc(p.fn + " " + p.ln) + " spent <b>Rs " + s.toLocaleString() + "</b>";
    } },
    { id: "c-passbook", kind: "cursor", keys: "cursor passenger bookings fetch loop r3", title: "cursor: bookings of passenger", run: function () {
      var p = O.passengers[0];
      var rows = O.bookings.filter(function (b) { return b.pass === p.id; }).slice(0, 8);
      var lines = rows.map(function (b) { return "FETCH → booking #" + b.id + " trip #" + b.trip + " seat " + b.seat + " Rs" + b.fare + " (" + b.status + ")"; });
      return "CURSOR c IS SELECT * FROM BOOKING WHERE PassengerID=" + p.id + " …<br>" + (lines.join("<br>") || "→ no bookings for " + esc(p.fn)) + "<br>CLOSE c;";
    } },
    { id: "p-maint", kind: "procedure", keys: "sp_schedule_maintenance vehicle service procedure r4", title: "sp_schedule_maintenance (due vehicle)", run: function () {
      var m = O.maintenance.slice().sort(function (a, b) { return a.next < b.next ? -1 : 1; })[0];
      var id = Math.max.apply(null, O.maintenance.map(function (x) { return x.id; })) + 1;
      O.maintenance.push({ id: id, vehicle: m.vehicle, date: "2026-03-01", next: "2026-06-01", type: "General Service", desc: "Demo via smart bar", cost: 180, status: "Scheduled" });
      if (window.refreshAll) refreshAll();
      return "BEGIN sp_schedule_maintenance(vehicle_id =&gt; " + m.vehicle + "); END;<br>→ SUCCESS maintenance #" + id + " scheduled for " + esc(vName(m.vehicle));
    } },
    { id: "t-maintdate", kind: "trigger", keys: "maintenance dates check next before date block exception r4", title: "trigger: bad maint. dates blocked", run: function () {
      return "INSERT INTO MAINTENANCE … (date=2026-05-01, next=2026-02-01);<br>→ ORA-20104: Next date must be &gt;= maintenance date. (CK_MAINTENANCE_DATES blocked it)";
    } },
    { id: "c-maintdue", kind: "cursor", keys: "cursor maintenance due vehicles fetch loop r4", title: "cursor: due vehicles", run: function () {
      var rows = O.maintenance.slice().sort(function (a, b) { return a.next < b.next ? -1 : 1; }).slice(0, 8);
      var lines = rows.map(function (m) { return "FETCH → " + esc(vName(m.vehicle)) + " next " + m.next + " (" + m.status + ")"; });
      return "CURSOR c IS SELECT * FROM MAINTENANCE WHERE NextDate &lt;= SYSDATE+30 …<br>" + lines.join("<br>") + "<br>CLOSE c;";
    } },
    { id: "f-maintover", kind: "function", keys: "fn_overdue_count maintenance function r4", title: "fn_overdue_count", run: function () {
      var today = new Date().toISOString().slice(0, 10);
      var n = O.maintenance.filter(function (m) { return m.next < today && m.status !== "Completed"; }).length;
      return "SELECT fn_overdue_count FROM DUAL;<br>→ <b>" + n + "</b> vehicle(s) overdue as of " + today;
    } },
    { id: "f-drvavg", kind: "function", keys: "fn_driver_avg_rating driver function r5", title: "fn_driver_avg_rating (top driver)", run: function () {
      var best = null, bestA = -1;
      O.drivers.forEach(function (d) {
        var ts = O.trips.filter(function (t) { return t.driver === d.id; }).map(function (t) { return t.id; });
        var fb = O.feedback.filter(function (f) { return ts.indexOf(f.trip) > -1; });
        var avg = fb.length ? fb.reduce(function (a, f) { return a + f.rating; }, 0) / fb.length : 0;
        if (avg > bestA) { bestA = avg; best = d; }
      });
      return "SELECT fn_driver_avg_rating(" + best.id + ") FROM DUAL;<br>→ " + esc(best.fn + " " + best.ln) + ": <b>" + (bestA ? bestA.toFixed(1) : "no ratings") + "</b>";
    } },
    { id: "t-fbrate", kind: "trigger", keys: "feedback rating 1-5 check trigger exception r5", title: "trigger: bad rating blocked", run: function () {
      return "INSERT INTO FEEDBACK … Rating=6;<br>→ ORA-20020: Rating must be 1-5. (sp_add_feedback / trigger blocked it)";
    } },
    { id: "c-drvperf", kind: "cursor", keys: "cursor driver performance trips rating fetch loop r5", title: "cursor: driver performance", run: function () {
      var lines = O.drivers.slice(0, 8).map(function (d) {
        var ts = O.trips.filter(function (t) { return t.driver === d.id; });
        var fb = O.feedback.filter(function (f) { return ts.some(function (t) { return t.id === f.trip; }); });
        var avg = fb.length ? (fb.reduce(function (a, f) { return a + f.rating; }, 0) / fb.length).toFixed(1) : "—";
        return "FETCH → " + esc(d.fn + " " + d.ln) + " : " + ts.length + " trip(s), avg " + avg;
      });
      return "CURSOR c IS SELECT driver, COUNT(*), AVG(rating) …<br>" + lines.join("<br>") + "<br>CLOSE c;";
    } },
    { id: "c-routes", kind: "cursor", keys: "cursor bookings per route fetch loop", title: "cursor: bookings per route", run: function () {
      var lines = O.routes.slice(0, 8).map(function (r) {
        var n = O.bookings.filter(function (b) { var t = O.trips.filter(function (x) { return x.id === b.trip; })[0]; return t && t.route === r.id; }).length;
        return "FETCH → " + esc(r.from + " → " + r.to) + " : " + n + " booking(s)";
      });
      return "CURSOR c IS SELECT route, COUNT(*) …<br>" + lines.join("<br>") + "<br>CLOSE c;";
    } }
  ];
  function matchOps(q) {
    q = (q || "").trim().toLowerCase();
    if (!q) return null;
    var toks = q.split(/\s+/);
    if (q === "view all" || q === "views" || q === "all views") return OPS.filter(function (o) { return o.kind === "view"; });
    return OPS.filter(function (o) {
      var hay = o.kind + " " + o.title.toLowerCase() + " " + o.keys;
      return toks.every(function (tk) { return hay.indexOf(tk) > -1; });
    });
  }
  function renderOps(sec) {
    var inp = document.getElementById("cmd-" + sec), box = document.getElementById("ops-" + sec);
    if (!inp || !box) return;
    var list = matchOps(inp.value);
    if (!list) {
      var prim = OPS.filter(function (o) { return o.id === PRIMARY[sec]; })[0];
      box.innerHTML = "";
      document.getElementById("res-" + sec).innerHTML = "<p style='color:#94a3b8'>Type in the smart bar to run database operations — e.g. <b>view all</b>, <b>procedure</b>, <b>trigger</b>, <b>cursor</b>, <b>function</b>.</p>"
        + "<p>Suggested: <button class='opbtn' data-op='" + prim.id + "' data-sec='" + sec + "'><i>" + prim.kind + "</i> · " + esc(prim.title) + "</button></p>";
      return;
    }
    box.innerHTML = list.length
      ? list.map(function (o) { return "<button class='opbtn' data-op='" + o.id + "' data-sec='" + sec + "'><i>" + o.kind + "</i> · " + esc(o.title) + "</button>"; }).join("")
      : "<span style='color:#94a3b8;font-size:13px'>No operation matches — try: view all, procedure, trigger, cursor, function.</span>";
  }
  function runOp(sec, opId) {
    var o = OPS.filter(function (x) { return x.id === opId; })[0];
    if (!o) return;
    var blk = document.getElementById("repBlock-" + sec);
    if (blk && blk.hidden) openViewer(sec);
    document.getElementById("res-" + sec).innerHTML = "<p><b>" + o.kind + ":</b> " + esc(o.title) + "</p>" + o.run();
  }
  function openViewer(sec, opId) {
    activeSec = sec;
    var b = document.getElementById("repBlock-" + sec);
    dockToBody(b);
    b.hidden = false;
    b.classList.add("open");
    runOp(sec, opId || PRIMARY[sec]);
    showSmart();
    var si = document.getElementById("smartCmd"); if (si) si.focus();
  }
  function anyViewerOpen() {
    var open = document.querySelectorAll(".repBlock.open");
    for (var i = 0; i < open.length; i++) if (!open[i].hidden) return true;
    return false;
  }
  function showSmart() {
    var s = document.getElementById("smartBar");
    if (s) { s.hidden = false; renderSmart(); }
  }
  function hideSmartIfAlone() {
    if (!anyViewerOpen()) { var s = document.getElementById("smartBar"); if (s) s.hidden = true; }
  }
  function renderSmart() {
    var inp = document.getElementById("smartCmd"), box = document.getElementById("smartOps");
    if (!inp || !box) return;
    var lbl = document.getElementById("smartCtx");
    if (lbl) lbl.textContent = "Report: " + activeSec.toUpperCase();
    var list = matchOps(inp.value);
    if (!list) {
      var prim = OPS.filter(function (o) { return o.id === PRIMARY[activeSec]; })[0];
      box.innerHTML = "<span style='color:#94a3b8;font-size:12px'>Showing " + activeSec.toUpperCase() + " operations only — e.g. <b>view</b>, <b>procedure</b>, <b>trigger</b>, <b>cursor</b>, <b>function</b>.</span>"
        + (prim ? "<p style='margin:8px 0 0'><button class='opbtn' data-op='" + prim.id + "' data-sec='" + activeSec + "'><i>" + prim.kind + "</i> · " + esc(prim.title) + "</button></p>" : "");
      return;
    }
    list = list.filter(function (o) { return OP_HOME[o.id] === activeSec; });
    box.innerHTML = list.length
      ? list.map(function (o) {
        return "<button class='opbtn' data-op='" + o.id + "' data-sec='" + activeSec + "'><i>" + o.kind + "</i> · " + esc(o.title) + "</button>";
      }).join("")
      : "<span style='color:#94a3b8;font-size:12px'>No " + activeSec.toUpperCase() + " operation matches — try: view, procedure, trigger, cursor, function.</span>";
  }
  function dockToBody(blk) {
    if (!blk._home) blk._home = { parent: blk.parentNode, next: blk.nextSibling };
    if (blk.parentNode !== document.body) document.body.appendChild(blk);
  }
  function restoreHome(blk) {
    if (blk._home && blk._home.parent) blk._home.parent.insertBefore(blk, blk._home.next);
  }
  function toggleBlock(sec) {
    var b = document.getElementById("repBlock-" + sec);
    if (!b.hidden) {
      b.hidden = true;
      b.classList.remove("open", "floating", "searched");
      b.style.left = ""; b.style.top = "";
      restoreHome(b);
      var f = document.querySelector("[data-float='" + sec + "']");
      if (f) f.textContent = "Float";
      return;
    }
    activeSec = sec;
    showSmart();
    var si = document.getElementById("smartCmd"); if (si) si.focus();
  }
  document.addEventListener("DOMContentLoaded", function () {
    if (!document.getElementById("smartBar")) {      var s = document.createElement("div");
      s.id = "smartBar"; s.hidden = true;
      s.innerHTML = "<div class='row repHead'><b>🔍 Smart search</b><span class='sp'></span><span id='smartCtx' style='font-size:11px;color:#7dd3fc'></span><button class='ghost' id='smartHide'>–</button></div>"
        + "<input id='smartCmd' placeholder='Search all ops: view all, procedure…'>"
        + "<div class='opList' id='smartOps' style='margin-top:8px'></div>";
      document.body.appendChild(s);
      document.getElementById("smartCmd").addEventListener("input", renderSmart);
      document.getElementById("smartCmd").addEventListener("keydown", function (e) {
        if (e.key === "Enter") { var first = document.querySelector("#smartOps .opbtn"); if (first) first.click(); }
      });
      document.getElementById("smartHide").addEventListener("click", function () { s.hidden = true; });
    }

    var btns = document.querySelectorAll("[data-rep]");
    for (var i = 0; i < btns.length; i++) (function (b) {
      b.addEventListener("click", function () { toggleBlock(b.getAttribute("data-rep")); });
    })(btns[i]);
    var fl = document.querySelectorAll("[data-float]");
    for (var j = 0; j < fl.length; j++) (function (b) {
      b.addEventListener("click", function () {
        var blk = document.getElementById("repBlock-" + b.getAttribute("data-float"));
        dockToBody(blk);
        blk.classList.toggle("floating");
        if (!blk.classList.contains("floating")) { blk.style.left = ""; blk.style.top = ""; }
        b.textContent = blk.classList.contains("floating") ? "Unfloat" : "Float";
      });
    })(fl[j]);
    var cl = document.querySelectorAll("[data-close]");
    for (var k = 0; k < cl.length; k++) (function (b) {
      b.addEventListener("click", function () {
        var blk = document.getElementById("repBlock-" + b.getAttribute("data-close"));
        blk.hidden = true; blk.classList.remove("floating"); blk.classList.remove("open"); blk.classList.remove("searched");
        blk.style.left = ""; blk.style.top = "";
        restoreHome(blk);
        var f = document.querySelector("[data-float='" + b.getAttribute("data-close") + "']");
        if (f) f.textContent = "Float";
      });
    })(cl[k]);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        var open = document.querySelectorAll(".repBlock.open");
        for (var i = 0; i < open.length; i++) {
          open[i].hidden = true; open[i].classList.remove("open"); open[i].classList.remove("floating"); open[i].classList.remove("searched");
          open[i].style.left = ""; open[i].style.top = "";
          restoreHome(open[i]);
        }
        var fs = document.querySelectorAll("[data-float]");
        for (var j = 0; j < fs.length; j++) fs[j].textContent = "Float";
        var sb = document.getElementById("smartBar"); if (sb) sb.hidden = true;
      }
    });
    (function () {
      var drag = null;
      document.addEventListener("pointerdown", function (e) {
        var head = e.target.closest ? (e.target.closest(".repBlock.open.floating .repHead") || e.target.closest("#smartBar .repHead")) : null;
        if (!head || e.target.closest("button") || e.target.closest("input")) return;
        var blk = head.closest(".repBlock") || document.getElementById("smartBar");
        var r = blk.getBoundingClientRect();
        drag = { blk: blk, dx: e.clientX - r.left, dy: e.clientY - r.top };
        head.setPointerCapture && e.pointerId !== undefined && head.setPointerCapture(e.pointerId);
        e.preventDefault();
      });
      document.addEventListener("pointermove", function (e) {
        if (!drag) return;
        var x = Math.max(0, Math.min(window.innerWidth - 120, e.clientX - drag.dx));
        var y = Math.max(0, Math.min(window.innerHeight - 60, e.clientY - drag.dy));
        drag.blk.style.left = x + "px"; drag.blk.style.top = y + "px";
      });
      document.addEventListener("pointerup", function () { drag = null; });
    })();
    var cmds = document.querySelectorAll("[data-cmd]");
    for (var m = 0; m < cmds.length; m++) (function (inp) {
      var sec = inp.getAttribute("data-cmd");
      inp.addEventListener("input", function () { renderOps(sec); });
      inp.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { var first = document.querySelector("#ops-" + sec + " .opbtn"); if (first) first.click(); }
      });
    })(cmds[m]);
    document.addEventListener("click", function (e) {
      var op = e.target.closest ? e.target.closest("[data-op]") : null;
      if (op) { activeSec = op.getAttribute("data-sec"); runOp(op.getAttribute("data-sec"), op.getAttribute("data-op")); return; }
      var ap = e.target.closest ? e.target.closest("[data-apply]") : null;
      if (ap) {
        var blk = ap.closest(".repBlock");
        var sec = blk.id.replace("repBlock-", "");
        runOp(sec, ap.getAttribute("data-apply"));
      }
    });
  });
})();
