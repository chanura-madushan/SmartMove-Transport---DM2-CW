function pwHash(s) { s = "sm$" + s; let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(16); }
function loadUsers() { try { return JSON.parse(localStorage.getItem("sm_users") || "{}"); } catch (e) { return {}; } }
function mongoUsers() { try { window.SM_MONGO.users = window.SM_MONGO.users || []; return window.SM_MONGO.users; } catch (e) { return []; } }
function syncMongoUser(u) { try { const users = loadUsers(); if (!users[u]) return; const mu = mongoUsers(); const rec = { username: u, h: users[u].h, since: users[u].since || "", pic: users[u].pic || "" }; const i = mu.findIndex(x => x.username === u); if (i >= 0) mu[i] = rec; else mu.push(rec); } catch (e) {} }
function syncAllMongoUsers() { try { Object.keys(loadUsers()).forEach(syncMongoUser); } catch (e) {} }
window.syncMongoUser = syncMongoUser;
function saveUsers(u) { try { localStorage.setItem("sm_users", JSON.stringify(u)); } catch (e) {} }
function loadHistory() { try { return JSON.parse(localStorage.getItem("sm_history") || "[]"); } catch (e) { return []; } }
function saveHistory(h) { try { localStorage.setItem("sm_history", JSON.stringify(h)); } catch (e) {} }
function remember(u) { const h = loadHistory().filter(x => x !== u); h.unshift(u); saveHistory(h.slice(0, 8)); }
function currentUser() { try { return localStorage.getItem("sm_session") || ""; } catch (e) { return ""; } }
function setSession(u) { try { if (u) localStorage.setItem("sm_session", u); else localStorage.removeItem("sm_session"); } catch (e) {} }
function validUsername(u) { return /^[A-Za-z0-9_]{3,16}$/.test(u); }
function validPassword(p) { return p.length >= 6 && /[A-Za-z]/.test(p) && /[0-9]/.test(p); }
function authTab(which) {
  const panes = { login: "authLoginPane", reg: "authRegPane", forgot: "authForgotPane" };
  for (const k in panes) document.getElementById(panes[k]).hidden = k !== which;
  document.getElementById("tabLogin").classList.toggle("on", which === "login");
  document.getElementById("tabReg").classList.toggle("on", which === "reg");
  ["loginErr", "regErr", "fgErr1", "fgErr2", "fgErr3"].forEach(id => { const e = document.getElementById(id); if (e) { e.textContent = ""; e.style.color = ""; } });
  if (which === "forgot") { document.getElementById("fgStep1").hidden = false; document.getElementById("fgStep2").hidden = true; document.getElementById("fgStep3").hidden = true; }
}
window.authTab = authTab;
function splashRun(fn) { const sp = document.getElementById("splash"); if (sp) sp.classList.remove("off"); setTimeout(() => { if (sp) sp.classList.add("off"); fn(); }, 900); }
window.splashRun = splashRun;
function enterApp(u) {
  splashRun(() => {
    document.getElementById("authGate").hidden = true;
    toast("Welcome, " + u);
    if(window.renderUserChip)window.renderUserChip();
    if(window.renderProfile)window.renderProfile();
    nav("dash");
  });
}
function authGate() {
  const sp0 = document.getElementById("splash"); if (sp0) sp0.classList.add("off");
  const users = loadUsers(), u = currentUser();
  syncAllMongoUsers();
  if (u && users[u]) { enterAppSilent(u); return; }
  setSession("");
  authTab("login");
  document.getElementById("authGate").hidden = false;
}
window.authGate = authGate;
function enterAppSilent(u) { document.getElementById("authGate").hidden = true; if(window.renderUserChip)window.renderUserChip(); nav("dash"); }
function doLogin(e) {
  e.preventDefault();
  const u = document.getElementById("loginUser").value.trim(), p = document.getElementById("loginPass").value;
  const err = document.getElementById("loginErr");
  if (!u || !p) { err.textContent = "Enter your username and password."; return false; }
  const users = loadUsers();
  if (!users[u] || users[u].h !== pwHash(p)) { err.textContent = "Invalid username or password."; return false; }
  setSession(u);
  remember(u);
  document.getElementById("loginPass").value = "";
  enterApp(u);
  return false;
}
window.doLogin = doLogin;
function doRegister(e) {
  e.preventDefault();
  const u = document.getElementById("regUser").value.trim(), p = document.getElementById("regPass").value, p2 = document.getElementById("regPass2").value;
  const err = document.getElementById("regErr");
  if (!validUsername(u)) { err.textContent = "Username must be 3-16 characters: letters, numbers, _ only."; return false; }
  const users = loadUsers();
  if (users[u]) { err.textContent = "That username is taken — try another."; return false; }
  if (!validPassword(p)) { err.textContent = "Password needs min 6 characters with at least one letter and one number."; return false; }
  if (p !== p2) { err.textContent = "Passwords do not match."; return false; }
  users[u] = { h: pwHash(p), since: new Date().toISOString().slice(0, 10) };
  saveUsers(users);
  syncMongoUser(u);
  remember(u);
  setSession("");
  document.getElementById("regPass").value = ""; document.getElementById("regPass2").value = "";
  splashRun(() => {
    authTab("login");
    document.getElementById("loginUser").value = u;
    document.getElementById("loginPass").value = "";
    const le = document.getElementById("loginErr");
    le.style.color = "#4ade80";
    le.textContent = "Account created — please log in.";
  });
  return false;
}
window.doRegister = doRegister;
function doForgotSend(e) {
  e.preventDefault();
  const u = document.getElementById("fgUser").value.trim();
  const err = document.getElementById("fgErr1");
  if (!loadUsers()[u]) { err.textContent = "No account with that username."; return false; }
  const code = String(Math.floor(100000 + Math.random() * 900000));
  try { localStorage.setItem("sm_reset", JSON.stringify({ u, code, exp: Date.now() + 10 * 60 * 1000 })); } catch (x) {}
  document.getElementById("fgCodeHint").textContent = "Demo code for " + u + ": " + code + " (valid 10 min — a real app would email/SMS this)";
  document.getElementById("fgStep1").hidden = true; document.getElementById("fgStep2").hidden = false;
  return false;
}
window.doForgotSend = doForgotSend;
function getReset() { try { return JSON.parse(localStorage.getItem("sm_reset") || "null"); } catch (e) { return null; } }
function doForgotVerify(e) {
  e.preventDefault();
  const err = document.getElementById("fgErr2"), r = getReset();
  if (!r || Date.now() > r.exp) { err.textContent = "Code expired — request a new one."; return false; }
  if (document.getElementById("fgCode").value.trim() !== r.code) { err.textContent = "Wrong code — check and try again."; return false; }
  document.getElementById("fgStep2").hidden = true; document.getElementById("fgStep3").hidden = false;
  return false;
}
window.doForgotVerify = doForgotVerify;
function doForgotReset(e) {
  e.preventDefault();
  const err = document.getElementById("fgErr3"), r = getReset();
  const p = document.getElementById("fgNew").value, p2 = document.getElementById("fgNew2").value;
  if (!r) { err.textContent = "Session expired — start over."; return false; }
  if (!validPassword(p)) { err.textContent = "Password needs min 6 characters with at least one letter and one number."; return false; }
  if (p !== p2) { err.textContent = "Passwords do not match."; return false; }
  const users = loadUsers();
  users[r.u] = users[r.u] || { since: new Date().toISOString().slice(0, 10) };
  users[r.u].h = pwHash(p);
  saveUsers(users);
  syncMongoUser(r.u);
  try { localStorage.removeItem("sm_reset"); } catch (x) {}
  setSession(r.u);
  remember(r.u);
  enterApp(r.u);
  return false;
}
window.doForgotReset = doForgotReset;
function doLogout() {
  setSession("");
  if(window.renderUserChip)window.renderUserChip();
  const sp = document.getElementById("splash");
  if (sp) sp.classList.remove("off");
  nav("dash");
  authTab("login");
  document.getElementById("authGate").hidden = true;
  setTimeout(() => { if (sp) sp.classList.add("off"); document.getElementById("authGate").hidden = false; }, 900);
  if (window.renderProfile) window.renderProfile();
}
window.doLogout = doLogout;
function switchAccount(n) {
  setSession("");
  if (window.renderUserChip) window.renderUserChip();
  nav("dash");
  authTab("login");
  document.getElementById("loginUser").value = n;
  document.getElementById("loginPass").value = "";
  document.getElementById("authGate").hidden = false;
}
window.switchAccount = switchAccount;
function accBtnHandler(e) {
  var b = e.target && e.target.closest ? e.target.closest("[data-acc-use]") : null;
  if (!b || !window._accList) return;
  var n = window._accList[+b.getAttribute("data-acc-use")];
  if (!n) return;
  switchAccount(n);
}
document.addEventListener("click", accBtnHandler);
if (!window._picHook) { window._picHook = true; document.addEventListener("change", function(e) {
  if (!e.target || e.target.id !== "picInput" || !e.target.files || !e.target.files[0]) return;
  var file = e.target.files[0];
  var rd = new FileReader();
  rd.onload = function() {
    var img = new Image();
    img.onload = function() {
      var s = 128, cv = document.createElement("canvas");
      cv.width = s; cv.height = s;
      var cx = cv.getContext("2d"), sc = Math.max(s / img.width, s / img.height);
      var w = img.width * sc, h = img.height * sc;
      cx.drawImage(img, (s - w) / 2, (s - h) / 2, w, h);
      var users = loadUsers(), u = currentUser();
      if (!u || !users[u]) return;
      users[u].pic = cv.toDataURL("image/jpeg", 0.8);
      try { saveUsers(users); } catch (x) { toast("Picture too large to save", false); return; }
      syncMongoUser(u);
      renderProfile();
      if (window.renderUserChip) window.renderUserChip();
    };
    img.src = rd.result;
  };
  rd.readAsDataURL(file);
}); }
function doUnarmDelete() { window._delArm = false; if (window.renderProfile) window.renderProfile(); }
window.doUnarmDelete = doUnarmDelete;
function doDeleteAccount() {
  const users = loadUsers(), u = currentUser();
  if (!u || !users[u]) return;
  if (!window._delArm) { window._delArm = true; renderProfile(); setTimeout(() => { if (window._delArm && currentUser() === u) { window._delArm = false; renderProfile(); } }, 6000); return; }
  window._delArm = false;
  delete users[u];
  saveUsers(users);
  try { const mu = mongoUsers(); const i = mu.findIndex(x => x.username === u); if (i >= 0) mu.splice(i, 1); } catch (x) {}
  setSession("");
  try { localStorage.removeItem("sm_reset"); } catch (x) {}
  if (window.renderUserChip) window.renderUserChip();
  nav("dash");
  authTab("login");
  document.getElementById("loginUser").value = "";
  document.getElementById("loginPass").value = "";
  document.getElementById("authGate").hidden = true;
  splashRun(() => { document.getElementById("authGate").hidden = false; });
}
window.doDeleteAccount = doDeleteAccount;
function renderProfile() {
  const el = document.getElementById("profEl");
  if (!el) return;
  const u = currentUser(), users = loadUsers();
  if (!u || !users[u]) {
    el.innerHTML = "<p style='font-size:13px;color:#94a3b8'>Not signed in.</p><button class='btn' onclick='doLogout()'>Go to login</button>";
    return;
  }
  el.innerHTML = "<div class='row' style='align-items:center'><div class='picWrap'><div class='avatar'>" + (users[u].pic ? "<img src='" + users[u].pic + "'>" : u[0].toUpperCase()) + "</div><label class='picAdd' title='Add picture'>+<input type='file' id='picInput' accept='image/*' hidden></label></div><div><b style='font-size:16px'>" + u.replace(/[<>&"]/g, "") + "</b><div style='font-size:12px;color:#94a3b8'>Member since " + (users[u].since || "—") + "</div></div><span style='flex:1'></span><button class='ghost' onclick='doLogout()'>Logout</button>"+(window._delArm?"<button class=ghost onclick='doDeleteAccount()'>Yes, delete</button> <button class=ghost onclick='doUnarmDelete()'>Cancel</button>":"<button class='ghost' onclick='doDeleteAccount()'>Delete account</button>")+"</div>";
  const acc = document.getElementById("accEl");
  if (acc) {
    var hist2 = loadHistory().filter(function(n){ return users[n]; });
    window._accList = hist2;
    acc.innerHTML = hist2.length ? hist2.map(function(n, i){
      var cur = n === u ? " (current)" : "";
      return '<div class="row" style="align-items:center"><div class="avatar" style="width:32px;height:32px;font-size:14px">' + (users[n] && users[n].pic ? "<img src='" + users[n].pic + "'>" : n[0].toUpperCase()) + '</div><b>' + n + cur + '</b><span style="flex:1"></span><button class="ghost" data-acc-use="' + i + '">Use</button></div>';
    }).join("") : '<p style="font-size:13px;color:#94a3b8">No accounts on this device yet.</p>';
  }
}
window.renderProfile = renderProfile;
function doChangePass(e) {
  e.preventDefault();
  const err = document.getElementById("cpErr");
  const u = currentUser(), users = loadUsers();
  if (!u || !users[u]) { err.textContent = "You are not signed in."; return false; }
  const cur = document.getElementById("cpCur").value, nw = document.getElementById("cpNew").value, nw2 = document.getElementById("cpNew2").value;
  if (users[u].h !== pwHash(cur)) { err.textContent = "Current password is wrong."; return false; }
  if (!validPassword(nw)) { err.textContent = "New password needs min 6 characters with at least one letter and one number."; return false; }
  if (nw !== nw2) { err.textContent = "New passwords do not match."; return false; }
  users[u].h = pwHash(nw);
  saveUsers(users);
  syncMongoUser(u);
  document.getElementById("cpCur").value = ""; document.getElementById("cpNew").value = ""; document.getElementById("cpNew2").value = "";
  err.textContent = "";
  splashRun(() => { toast("Password updated"); });
  return false;
}
window.doChangePass = doChangePass;

function exitSite() { try { window.close(); } catch (e) {}
  setTimeout(() => { if (window.closed) return;
    const sp = document.getElementById("splash");
    if (sp) sp.classList.remove("off");
  }, 350); }
window.exitSite = exitSite;
