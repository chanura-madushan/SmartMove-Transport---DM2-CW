const O = window.SM_ORACLE, M = window.SM_MONGO;
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function toast(m, ok = true) { const t = $("toastEl"); t.style.display = "block"; t.style.borderColor = ok ? "#10b981" : "#ef4444"; t.textContent = m; clearTimeout(t._x); t._x = setTimeout(() => t.style.display = "none", 3200); }
const PAGE_META={dash:["Dashboard","Overview"],vehicles:["Vehicles","Fleet + media"],drivers:["Drivers","Staff"],routes:["Routes","Network"],pass:["Passengers","Registry"],trips:["Trips","Schedule"],bookings:["Bookings","sp_book_ticket"],payments:["Payments","Revenue"],maint:["Maintenance","Upkeep"],feedback:["Feedback","Ratings"],community:["Community","MongoDB"],ann:["Announcements","MongoDB"],about:["About us","SmartMove"],settings:["Settings","App"],profile:["Profile","Account"]};
function nav(p){if(!$("pg-"+p))p="dash";document.querySelectorAll(".page").forEach(e=>e.classList.remove("on"));$("pg-"+p).classList.add("on");document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("on",b.dataset.p===p));document.querySelectorAll(".mnav button").forEach(b=>b.classList.toggle("on",b.dataset.p===p));const m=PAGE_META[p]||[p,""];if($("pageTitleEl"))$("pageTitleEl").textContent=m[0];if($("pageSubEl"))$("pageSubEl").textContent=m[1];toggleSide(false);document.documentElement.classList.toggle("hideScroll",p==="dash");document.querySelectorAll('.page').forEach(x=>x.classList.remove('stuck'));R[p]&&R[p]();window.scrollTo(0,0);fixStick();setTimeout(()=>{fixStick();updateStuck();},50);}
function toggleSide(force){const s=document.querySelector(".side");const sc=$("scrim");const open=typeof force==="boolean"?force:!s.classList.contains("open");s.classList.toggle("open",open);if(sc)sc.classList.toggle("on",open);}
window.toggleSide=toggleSide;
function renderUserChip(){const el=$("userChip");if(!el)return;let u="";try{u=localStorage.getItem("sm_session")||""}catch(e){}if(!u){el.innerHTML="<button onclick=\"nav('profile')\">Sign in</button>";return;}let pic="";try{const us=(window.loadUsers?window.loadUsers():{});if(us[u]&&us[u].pic)pic=us[u].pic;}catch(e){}el.innerHTML="<span class=ubadge>"+(pic?"<img src='"+pic+"'>":u[0].toUpperCase())+"</span><b>"+u.replace(/[<>&]/g,"").replace(/[\"']/g,"")+"</b><button onclick=\"doLogout()\">Logout</button>";}
window.renderUserChip=renderUserChip;
function getLayout(){try{return localStorage.getItem("sm_layout")||"auto"}catch(e){return "auto"}}
function setLayout(m){try{localStorage.setItem("sm_layout",m)}catch(e){}applyLayout();syncLayoutUI();}
window.setLayout=setLayout;
function applyLayout(){const m=getLayout();if(m==="auto")document.body.removeAttribute("data-layout");else document.body.setAttribute("data-layout",m);}
window.applyLayout=applyLayout;
function fixStick(){try{const bar=$("connBar");let h=0;if(bar&&bar.style.display!=="none"&&getComputedStyle(bar).display!=="none")h=Math.ceil(bar.getBoundingClientRect().height);document.body.style.setProperty("--rep-top",h+"px");}catch(e){}}
window.fixStick=fixStick;
window.addEventListener("resize",()=>{if(window.fixStick)fixStick();});
let tourRsT = null;
window.addEventListener("resize",()=>{clearTimeout(tourRsT);tourRsT=setTimeout(()=>{try{if(document.querySelector("#pg-dash.on")&&$("tourTrack"))renderTour();}catch(e){}},250);});
window.addEventListener("pagehide",()=>{const sp=document.getElementById("splash");if(sp)sp.classList.remove("off");});
function updateStuck(){try{const pg=document.querySelector(".page.on");if(!pg)return;const rep=pg.querySelector(".repbar");if(!rep){pg.classList.remove("stuck");return;}const bar=$("connBar");let bh=0;if(bar&&bar.style.display!=="none"&&getComputedStyle(bar).display!=="none")bh=Math.ceil(bar.getBoundingClientRect().height);const stuck=rep.getBoundingClientRect().top<=bh+2&&window.scrollY>10;pg.classList.toggle("stuck",stuck);}catch(e){}}
window.updateStuck=updateStuck;
window.addEventListener("scroll",()=>{if(window.updateStuck)updateStuck();},{passive:true});
document.querySelectorAll(".page").forEach(pg=>{const rep=pg.querySelector(":scope > .repbar");if(!rep||rep.parentElement.classList.contains("stickWrap"))return;const wrap=document.createElement("div");wrap.className="stickWrap";pg.insertBefore(wrap,rep);wrap.appendChild(rep);const crud=pg.querySelector(":scope > .panel.crud");if(!crud)return;let n=wrap.nextSibling,seenCrud=false;while(n){const nx=n.nextSibling;if(n.nodeType===1){const isC=n.classList.contains("crud"),isS=n.classList.contains("stick");if(!seenCrud){wrap.appendChild(n);if(isC)seenCrud=true;}else if(isS){wrap.appendChild(n);}else break;}n=nx;}});
{const side=document.querySelector(".side");if(side&&!side.querySelector(".sideHead")){const head=document.createElement("div");head.className="sideHead";const navEl=side.querySelector(".nav");side.insertBefore(head,navEl);[".logo",".sub","#userChip"].forEach(s=>{const el=side.querySelector(":scope > "+s);if(el)head.appendChild(el);});}}
function syncLayoutUI(){const m=getLayout();document.querySelectorAll('input[name="layoutMode"]').forEach(r=>{r.checked=r.value===m;});}
window.syncLayoutUI=syncLayoutUI;
window.nav = nav;
const vName = id => { const v = O.vehicles.find(x => x.id == id); return v ? v.reg + " (" + v.type + ")" : id; };
const dName = id => { const d = O.drivers.find(x => x.id == id); return d ? d.fn + " " + d.ln : id; };
const rName = id => { const r = O.routes.find(x => x.id == id); return r ? r.from + " → " + r.to : id; };
const pName = id => { const p = O.passengers.find(x => x.id == id); return p ? p.fn + " " + p.ln : id; };
function tbl(heads, rows) { return "<div style='overflow:auto'><table><tr>" + heads.map(h => "<th>" + h + "</th>").join("") + "</tr>" + rows.map(r => "<tr>" + r.map(c => "<td>" + c + "</td>").join("") + "</tr>").join("") + "</table></div>"; }
function opts(list, v, t) { return list.map(x => "<option value='" + x[v] + "'>" + esc(x[t] ?? x[v]) + "</option>").join(""); }
function spBook(pass, trip, seat, fare) {
  const t = O.trips.find(x => x.id == trip); if (!t) throw "Invalid trip.";
  if (!O.passengers.find(x => x.id == pass)) throw "Invalid passenger.";
  const v = O.vehicles.find(x => x.id == t.vehicle); const cap = v ? v.cap : 30;
  if (!(seat >= 1 && seat <= cap)) throw "Invalid seat for vehicle capacity (" + cap + ").";
  if (O.bookings.some(b => b.trip == trip && b.seat == seat && b.status === "Confirmed")) throw "The selected seat is already booked.";
  const id = Math.max(...O.bookings.map(b => b.id)) + 1;
  O.bookings.push({ id, pass: +pass, trip: +trip, date: new Date().toISOString().slice(0, 10), seat: +seat, fare: +fare, status: "Confirmed" });
  return id;
}
function tripCap(t) { const v = O.vehicles.find(x => x.id === t.vehicle); return v ? v.cap : 30; }
function tripTaken(tid) { return O.bookings.filter(b => b.trip === tid && b.status === "Confirmed").map(b => b.seat); }
function renderSeatAvail() {
  const t = O.trips.find(x => x.id === +$("bkTrip").value); if (!t || !$("seatAvailEl")) return;
  const cap = tripCap(t), taken = tripTaken(t.id).sort((a, b) => a - b);
  $("seatTitle").textContent = "Seat availability — Trip #" + t.id + " " + rName(t.route) + " (" + taken.length + "/" + cap + " taken)";
  $("seatAvailEl").textContent = taken.length ? "Taken seats: " + taken.join(", ") + ". Type free seat numbers separated by commas, e.g. 6,7,8." : "All " + cap + " seats free. Type seat numbers separated by commas, e.g. 6,7,8.";
}
function delAnn(i) { M.announcements.splice(i, 1); toast("Announcement removed"); R.ann(); R.dash(); }
window.delAnn = delAnn;
let annIdx = 0; const ANN_PER = 3;
function annCard(a) { return "<div class=card><b style='font-size:14px'>[" + esc(a.priority) + "] " + esc(a.title) + "</b><div style='font-size:13px;color:#94a3b8'>" + esc(a.message) + "</div><div style='font-size:11px;color:#64748b'>" + esc((a.created || "") + (a.time ? " " + a.time : "")) + "</div></div>"; }
function renderAnn() {
  const n = Math.max(1, Math.ceil(M.announcements.length / ANN_PER));
  annIdx = ((annIdx % n) + n) % n;
  $("annEl").innerHTML = M.announcements.slice(annIdx * ANN_PER, annIdx * ANN_PER + ANN_PER).map(annCard).join("");
  const c = $("annCaps"); if (c) c.textContent = (annIdx + 1) + " / " + n;
  annAuto();
}
function annNext() { annIdx++; renderAnn(); }
window.annNext = annNext;
let annTimer = null;
function annAuto() {
  if (annTimer) clearInterval(annTimer);
  annTimer = setInterval(() => { if (document.querySelector("#pg-dash.on") && $("annEl")) annNext(); }, 5000);
}
document.addEventListener("dblclick", e => {
  const p = e.target && e.target.closest ? e.target.closest("#annPanel") : null;
  if (!p || (e.target.closest && e.target.closest("#annCaps"))) return;
  const r = p.getBoundingClientRect();
  annIdx += (e.clientX < r.left + r.width / 2 ? -1 : 1);
  renderAnn();
});
let fbTab = "oracle";
function setFbTab(t) {
  fbTab = t;
  if ($("fbTabOracle")) $("fbTabOracle").classList.toggle("on", t === "oracle");
  if ($("fbTabMongo")) $("fbTabMongo").classList.toggle("on", t === "mongo");
  R.feedback();
}
window.setFbTab = setFbTab;
const R = {
  dash() {
    const rev = O.payments.filter(p => p.status === "Paid").reduce((a, p) => a + p.amt, 0);
    $("statEl").innerHTML = [["Vehicles", O.vehicles.length], ["Drivers", O.drivers.length], ["Routes", O.routes.length], ["Passengers", O.passengers.length], ["Trips", O.trips.length], ["Bookings", O.bookings.length], ["Revenue", "Rs " + rev.toLocaleString()]].map(s => "<div class=card><h3>" + s[0] + "</h3><b>" + s[1] + "</b></div>").join("");
    renderAnn();
    renderTour();
  },
  vehicles() {
    $("vehEl").innerHTML = tbl(["ID", "Reg", "Type", "Cap", "Status", "Media", "Actions"], O.vehicles.map(v => {
      const n = M.vehicle_media.filter(m => m.vehicle_id === v.id).length;
      return [v.id, esc(v.reg), v.type, v.cap, "<span class=tag>" + v.status + "</span>", n ? "📎 " + n + " file(s)" : "—",
        "<button class=ghost onclick=\"cycleVehicle(" + v.id + ")\">Next&nbsp;status</button> <button class=ghost onclick=\"delRow('vehicle'," + v.id + ")\">Del</button>"];
    }));
  },
  pass() {
    $("passEl").innerHTML = tbl(["ID", "First", "Last", "Phone", "Email", "Actions"], O.passengers.map(p =>
      [p.id, esc(p.fn), esc(p.ln), esc(p.phone), esc(p.email || "—"),
      "<button class=ghost onclick=\"editRow('passenger'," + p.id + ")\">Edit</button> <button class=ghost onclick=\"delRow('passenger'," + p.id + ")\">Del</button>"]));
  },
  drivers() { $("drvEl").innerHTML = tbl(["ID", "Name", "License", "Phone", "Status", "Actions"], O.drivers.map(d => [d.id, esc(d.fn + " " + d.ln), d.lic, d.phone, "<span class=tag>" + d.status + "</span>",
    "<button class=ghost onclick=\"editRow('driver'," + d.id + ")\">Edit</button> <button class=ghost onclick=\"delRow('driver'," + d.id + ")\">Del</button>"])); },
  routes() { $("rouEl").innerHTML = tbl(["ID", "From", "To", "KM", "Status", "Actions"], O.routes.map(r => [r.id, esc(r.from), esc(r.to), r.km, r.status,
    "<button class=ghost onclick=\"editRow('route'," + r.id + ")\">Edit</button> <button class=ghost onclick=\"delRow('route'," + r.id + ")\">Del</button>"])); },
  trips() {
    $("tripEl").innerHTML = tbl(["ID", "Route", "Date", "Dep", "Vehicle", "Driver", "Seats", "Status", "Mongo", "Del"], O.trips.map(t => {
      const m = M.trip_media.filter(x => x.trip_id === t.id).length + M.announcements.filter(a => a.route_id === t.route).length;
      const cap = tripCap(t), tk = tripTaken(t.id).length;
      return [t.id, esc(rName(t.route)), t.date, t.dep, esc(vName(t.vehicle)), esc(dName(t.driver)), tk + "/" + cap + (tk >= cap ? " FULL" : ""), "<span class=tag>" + t.status + "</span>", m ? "📎" + m : "—",
        "<button class=ghost onclick=\"delRow('trip'," + t.id + ")\">Del</button>"];
    }));
  },
  bookings() {
    $("bookEl").innerHTML = tbl(["ID", "Passenger", "Trip", "Seat", "Fare", "Status", "Action"], O.bookings.map(b => [b.id, esc(pName(b.pass)), "#" + b.trip + " " + esc(rName((O.trips.find(t => t.id === b.trip) || {}).route)), b.seat, b.fare, b.status,
      b.status === "Confirmed" ? "<button class=ghost onclick=\"cancelBooking(" + b.id + ")\">Cancel</button>" : "—"]));
  },
  payments() { $("payEl").innerHTML = tbl(["ID", "Booking (seat)", "Trip", "Date", "Amt", "Method", "Status"], O.payments.map(p => { const b = O.bookings.find(x => x.id === p.booking) || {}; const t = O.trips.find(x => x.id === b.trip) || {}; return [p.id, "#" + p.booking + " • seat " + (b.seat ?? "—"), "#" + (b.trip ?? "—") + " " + esc(rName(t.route)), p.date, p.amt, p.method, p.status]; })); },
  maint() { $("mntEl").innerHTML = tbl(["ID", "Vehicle", "Date", "Next", "Type", "Cost", "Status", "Actions"], O.maintenance.map(m => [m.id, esc(vName(m.vehicle)), m.date, m.next, esc(m.type), m.cost, m.status,
    "<button class=ghost onclick=\"cycleMaint(" + m.id + ")\">Next&nbsp;status</button> <button class=ghost onclick=\"delRow('maint'," + m.id + ")\">Del</button>"])); },
  feedback() {
    if ($("fbTabOracle")) $("fbTabOracle").classList.toggle("on", fbTab === "oracle");
    if ($("fbTabMongo")) $("fbTabMongo").classList.toggle("on", fbTab === "mongo");
    if (fbTab === "mongo") {
      $("fbEl").innerHTML = tbl(["Passenger", "Route", "Rating", "Comment", "Tags", "Date"], M.reviews.map(r => [esc(pName(r.passenger_id)), esc(rName(r.route_id)), "★".repeat(r.rating), esc(r.comment), (r.tags || []).join(", "), r.created || "—"]));
    } else {
      $("fbEl").innerHTML = tbl(["ID", "Passenger", "Trip", "Rating", "Comment", "Date"], O.feedback.map(f => [f.id, esc(pName(f.pass)), "#" + f.trip, "★".repeat(f.rating), esc(f.text), f.date || "—"]));
    }
  },
  ann() {
    $("annEl2").innerHTML = M.announcements.map((a, i) => "<div class=card><b>[" + esc(a.priority) + "] " + esc(a.title) + "</b><div style='font-size:13px;color:#94a3b8'>" + esc(a.message) + "</div><div style='font-size:11px;color:#64748b'>" + esc((a.created || "") + (a.time ? " " + a.time : "")) + "</div><div style='margin-top:8px'><button class=ghost onclick=\"delAnn(" + i + ")\">Remove</button></div></div>").join("");
  },
  community() {
    $("medEl").innerHTML = "<div class=media>" + M.vehicle_media.map(m => "<div class=mimg style='background:" + m.color + "33;border:1px solid " + m.color + "'>" + esc(m.title) + " • Veh " + m.vehicle_id + "</div>").join("") + "</div>";
    $("revEl").innerHTML = tbl(["Route", "Rating", "Comment", "Search", "Date"], M.reviews.map(r => [esc(rName(r.route_id)), r.rating + "/5", esc(r.comment), esc((r.tags || []).join(", ")), r.created || "—"]));
  },
  about() {},
  profile() { if (window.renderProfile) window.renderProfile(); },
  settings() { if (window.syncLayoutUI) window.syncLayoutUI(); if (window.syncConnToggle) window.syncConnToggle(); },
};
function fixStickSoon(){setTimeout(()=>{if(window.fixStick)fixStick();},50);}
function syncConnToggle(){const t=$("connBarToggle"),bar=$("connBar");if(!t||!bar)return;const on=bar.style.display!=="none"&&getComputedStyle(bar).display!=="none";t.classList.toggle("bad",!on);t.innerHTML="<span class='dot'></span>Connection bar: "+(on?"ON":"OFF");}
window.syncConnToggle=syncConnToggle;
function toggleConnBar(on) {
  const bar = $("connBar");
  if(on===undefined)on=bar.style.display==="none"||getComputedStyle(bar).display==="none";
  if (bar) bar.style.display = on ? "" : "none";
  try { localStorage.setItem("sm_connbar", on ? "1" : "0"); } catch (e) {} syncConnToggle(); fixStickSoon();
}
window.toggleConnBar = toggleConnBar;
function checkConns() {
  CONNS.oracle.ok = !!(window.SM_ORACLE && window.SM_ORACLE.vehicles && window.SM_ORACLE.vehicles.length);
  CONNS.mongo.ok = !!(window.SM_MONGO && window.SM_MONGO.announcements);
  renderConns();
  const bad = Object.keys(CONNS).filter(k => !CONNS[k].ok);
  if (!bad.length) toast("Connections OK — Oracle (" + CONNS.oracle.db + ") + MongoDB (" + CONNS.mongo.db + ")");
  else toast("Connection failed — " + bad.map(k => CONNS[k].label + " (" + CONNS[k].db + ")").join(", "), false);
}
window.checkConns = checkConns;


window.R = R;
function fill() {
  $("bkPass").innerHTML = O.passengers.map(p => "<option value='" + p.id + "'>" + esc(p.fn + " " + p.ln) + "</option>").join("");
  $("bkTrip").innerHTML = O.trips.map(t => "<option value='" + t.id + "'>#" + t.id + " " + esc(rName(t.route)) + " " + t.date + "</option>").join("");
  $("fbPass").innerHTML = $("bkPass").innerHTML; $("fbTrip").innerHTML = $("bkTrip").innerHTML;
  $("payBook").innerHTML = O.bookings.filter(b => b.status === "Confirmed").map(b => "<option value='" + b.id + "'>#" + b.id + " " + esc(pName(b.pass)) + " • seat " + b.seat + " • Rs" + b.fare + "</option>").join("") || "<option value=''>— no unpaid bookings —</option>";
  if ($("tVeh")) $("tVeh").innerHTML = O.vehicles.map(v => "<option value='" + v.id + "'>" + esc(v.reg + " (" + v.type + ", cap " + v.cap + ")") + "</option>").join("");
  if ($("tDrv")) $("tDrv").innerHTML = O.drivers.map(d => "<option value='" + d.id + "'>" + esc(d.fn + " " + d.ln) + "</option>").join("");
  if ($("tRou")) $("tRou").innerHTML = O.routes.map(r => "<option value='" + r.id + "'>" + esc(r.from + " → " + r.to) + "</option>").join("");
  if ($("mVeh")) $("mVeh").innerHTML = O.vehicles.map(v => "<option value='" + v.id + "'>" + esc(v.reg) + "</option>").join("");
  if ($("fltPass") && !$("fltPass").options.length) $("fltPass").innerHTML = "<option value=''>all passengers</option>" + $("bkPass").innerHTML;
  if ($("fltRoute") && !$("fltRoute").options.length) $("fltRoute").innerHTML = "<option value=''>all routes</option>" + O.routes.map(r => "<option value='" + r.id + "'>" + esc(r.from + " → " + r.to) + "</option>").join("");
  if ($("bkTrip")) $("bkTrip").onchange = () => { const t = O.trips.find(x => x.id === +$("bkTrip").value); if (t) { const r = O.routes.find(x => x.id === t.route); $("bkFare").value = Math.round((r ? r.km : 100) * 2.5); } renderSeatAvail(); };
  renderSeatAvail();
}
function doBook(e) {
  e.preventDefault();
  const seats = ($("bkSeats").value || "").split(/[,\s]+/).map(s => +s).filter(s => Number.isFinite(s) && s >= 1);
  if (!seats.length) { toast("Enter seat numbers, e.g. 6,7,8.", false); return; }
  const dup = seats.filter((s, i) => seats.indexOf(s) !== i);
  if (dup.length) { toast("Duplicate seats in request: " + [...new Set(dup)].join(", "), false); return; }
  const ids = [];
  try {
    for (const s of seats) ids.push(spBook(+$("bkPass").value, +$("bkTrip").value, s, +$("bkFare").value));
    toast("Booked " + ids.length + " seat(s) via sp_book_ticket ✅ IDs " + ids.join(", ") + " (one BOOKING row per seat)"); R.bookings(); R.trips(); fill(); renderSeatAvail();
  } catch (err) { toast("Booking failed at seat " + (ids.length + 1) + ": " + err + (ids.length ? " (" + ids.length + " earlier seat(s) kept: IDs " + ids.join(", ") + ")" : ""), false); R.bookings(); R.trips(); fill(); renderSeatAvail(); }
}
function doPay(e) {
  e.preventDefault();
  const b = +$("payBook").value;
  if (O.payments.some(p => p.booking === b)) return toast("Payment already recorded for booking.", false);
  const bk = O.bookings.find(x => x.id === b);
  O.payments.push({ id: Math.max(...O.payments.map(p => p.id)) + 1, booking: b, date: new Date().toISOString().slice(0, 10), amt: bk ? bk.fare : +$("payAmt").value, method: $("payMethod").value, status: "Paid" });
  toast("Payment recorded via sp_record_payment ✅"); R.payments();
}
function doFb(e) {
  e.preventDefault();
  const r = +$("fbRate").value; if (!(r >= 1 && r <= 5)) return toast("Rating must be 1-5.", false);
  const t = O.trips.find(x => x.id == $("fbTrip").value);
  if (fbTab === "mongo") {
    M.reviews.unshift({ passenger_id: +$("fbPass").value, trip_id: +$("fbTrip").value, route_id: t ? t.route : null, rating: r, comment: $("fbText").value, tags: ["web"], created: new Date().toISOString().slice(0, 10) });
    toast("Feedback saved to Mongo reviews ✅"); $("fbText").value = ""; R.feedback(); R.community(); return;
  }
  if (O.feedback.some(f => f.pass == $("fbPass").value && f.trip == $("fbTrip").value)) return toast("Feedback already given for this trip.", false);
  O.feedback.push({ id: Math.max(...O.feedback.map(f => f.id)) + 1, pass: +$("fbPass").value, trip: +$("fbTrip").value, rating: r, text: $("fbText").value, date: new Date().toISOString().slice(0, 10) });
  toast("Feedback saved to Oracle FEEDBACK ✅"); $("fbText").value = ""; R.feedback(); R.community();
}
function addVehicle(e) { e.preventDefault(); const id = Math.max(...O.vehicles.map(v => v.id)) + 1; O.vehicles.push({ id, reg: $("vReg").value, type: $("vType").value, cap: +$("vCap").value, status: $("vStat").value }); toast("Vehicle added ✅"); R.vehicles(); }
function addAnn(e) { e.preventDefault(); const now = new Date(), pad = n => String(n).padStart(2, "0");
  M.announcements.unshift({ title: $("aTitle").value, message: $("aMsg").value, route_id: null, priority: $("aPri").value, created: now.toISOString().slice(0, 10), time: pad(now.getHours()) + ":" + pad(now.getMinutes()) }); toast("Announcement posted to MongoDB ✅"); e.target.reset(); R.ann(); R.dash(); }
function refreshAll() { fill(); Object.keys(R).forEach(k => { try { if ($("pg-" + k) && $("pg-" + k).classList.contains("on")) R[k](); } catch(e){} }); ["vehicles","drivers","routes","pass","trips","bookings","payments","maint"].forEach(k => { const m = {vehicles:"vehicles",drivers:"drivers",routes:"routes",pass:"pass",trips:"trips",bookings:"bookings",payments:"payments",maint:"maint"}[k]; try { R[m](); } catch(e){} }); }
function addDriver(e) { e.preventDefault();
  if (O.drivers.some(d => d.lic.toLowerCase() === $("dLic").value.trim().toLowerCase())) return toast("Duplicate license (UQ_DRIVER_LICENSE).", false);
  const id = Math.max(...O.drivers.map(d => d.id)) + 1;
  O.drivers.push({ id, fn: $("dFn").value.trim(), ln: $("dLn").value.trim(), lic: $("dLic").value.trim(), phone: $("dPhone").value.trim(), status: $("dStat").value });
  toast("Driver added ✅ (INSERT INTO DRIVER)"); e.target.reset(); refreshAll(); }
function addRoute(e) { e.preventDefault();
  const km = +$("rKm").value; if (!(km > 0)) return toast("Distance must be > 0 (CK_ROUTE_DISTANCE).", false);
  const id = Math.max(...O.routes.map(r => r.id)) + 1;
  O.routes.push({ id, from: $("rFrom").value.trim(), to: $("rTo").value.trim(), km, status: $("rStat").value });
  toast("Route added ✅ (INSERT INTO ROUTE)"); e.target.reset(); refreshAll(); }
function addPassenger(e) { e.preventDefault();
  const em = $("pEmail").value.trim();
  if (em && O.passengers.some(p => (p.email || "").toLowerCase() === em.toLowerCase())) return toast("Email already registered (UQ_PASSENGER_EMAIL).", false);
  const id = Math.max(...O.passengers.map(p => p.id)) + 1;
  O.passengers.push({ id, fn: $("pFn").value.trim(), ln: $("pLn").value.trim(), phone: $("pPhone").value.trim(), email: em || null });
  toast("Passenger registered ✅ (INSERT INTO PASSENGER)"); e.target.reset(); refreshAll(); }
function addTrip(e) { e.preventDefault();
  const id = Math.max(...O.trips.map(t => t.id)) + 1;
  O.trips.push({ id, vehicle: +$("tVeh").value, driver: +$("tDrv").value, route: +$("tRou").value, date: $("tDate").value, dep: $("tDep").value, arr: "", status: $("tStat").value });
  toast("Trip scheduled ✅ (INSERT INTO TRIP)"); refreshAll(); renderSeatAvail(); }
function addMaint(e) { e.preventDefault();
  if ($("mNext").value < $("mDate").value) return toast("Next date must be >= date (CK_MAINTENANCE_DATES).", false);
  const id = Math.max(...O.maintenance.map(m => m.id)) + 1;
  O.maintenance.push({ id, vehicle: +$("mVeh").value, date: $("mDate").value, next: $("mNext").value, type: $("mType").value, desc: "Scheduled via app", cost: +$("mCost").value, status: "Scheduled" });
  toast("Maintenance scheduled ✅"); e.target.reset(); refreshAll(); }
function cancelBooking(id) { const b = O.bookings.find(x => x.id === id); if (!b) return; b.status = "Cancelled"; toast("Booking #" + id + " cancelled (UPDATE BOOKING). Free seat " + b.seat + " on trip #" + b.trip + "."); refreshAll(); renderSeatAvail(); }
function cycleVehicle(id) { const v = O.vehicles.find(x => x.id === id); const seq = ["Available", "In Service", "Maintenance"]; v.status = seq[(seq.indexOf(v.status) + 1) % seq.length]; toast("Vehicle " + v.reg + " \u2192 " + v.status); R.vehicles(); }
window.cycleVehicle = cycleVehicle;
function cycleMaint(id) { const m = O.maintenance.find(x => x.id === id); const seq = ["Scheduled","In Progress","Completed","Cancelled"]; m.status = seq[(seq.indexOf(m.status) + 1) % seq.length]; toast("Maintenance #" + id + " → " + m.status); R.maint(); }
function delRow(kind, id) {
  const used = (arr, fn, label) => { if (O[arr].some(fn)) { toast("Cannot delete: still referenced by " + label + " (FK constraint).", false); return true; } return false; };
  if (kind === "vehicle") { if (used("trips", t => t.vehicle === id, "TRIP") || used("maintenance", m => m.vehicle === id, "MAINTENANCE")) return; O.vehicles = O.vehicles.filter(v => v.id !== id); }
  if (kind === "driver") { if (used("trips", t => t.driver === id, "TRIP")) return; O.drivers = O.drivers.filter(d => d.id !== id); }
  if (kind === "route") { if (used("trips", t => t.route === id, "TRIP")) return; O.routes = O.routes.filter(r => r.id !== id); }
  if (kind === "passenger") { if (used("bookings", b => b.pass === id, "BOOKING")) return; O.passengers = O.passengers.filter(p => p.id !== id); }
  if (kind === "trip") { if (used("bookings", b => b.trip === id, "BOOKING")) return; O.trips = O.trips.filter(t => t.id !== id); }
  if (kind === "maint") O.maintenance = O.maintenance.filter(m => m.id !== id);
  toast("Deleted ✅ (DELETE FROM " + kind.toUpperCase() + " WHERE id=" + id + ")"); refreshAll();
}
function editRow(kind, id) {
  const g = (msg, cur) => prompt(msg, cur);
  if (kind === "vehicle") { const v = O.vehicles.find(x => x.id === id); const s = g("Status (Available/In Service/Inactive):", v.status); if (!s) return;
    if (!["Available","In Service","Inactive"].includes(s)) return toast("Invalid status (CK_VEHICLE_STATUS).", false); v.status = s; }
  if (kind === "driver") { const d = O.drivers.find(x => x.id === id); const p = g("Phone:", d.phone); if (p === null) return; const s = g("Status (Available/On Trip/Inactive):", d.status); if (s === null) return;
    if (!["Available","On Trip","Inactive"].includes(s)) return toast("Invalid status.", false); d.phone = p; d.status = s; }
  if (kind === "route") { const r = O.routes.find(x => x.id === id); const km = g("Distance KM (>0):", r.km); if (km === null) return;
    if (!(+km > 0)) return toast("Distance must be > 0.", false); r.km = +km; const s = g("Status (Active/Inactive):", r.status); if (s && ["Active","Inactive"].includes(s)) r.status = s; }
  if (kind === "passenger") { const p = O.passengers.find(x => x.id === id); const ph = g("Phone:", p.phone); if (ph === null) return; const em = g("Email (optional):", p.email || "");
    if (em && O.passengers.some(x => x.id !== id && (x.email || "").toLowerCase() === em.toLowerCase())) return toast("Email already used.", false); p.phone = ph; p.email = em || null; }
  toast("Updated ✅ (UPDATE " + kind.toUpperCase() + ")"); refreshAll();
}
function runProc(which) {
  const out = $("labEl"); const log = s => { out.textContent += "\n" + s; };
  if (which === "book") { out.textContent = "BEGIN sp_book_ticket(p_pass=1, p_trip=1, p_seat=2, p_fare=300);";
    try { const id = spBook(1, 1, 2, 300); log("→ SUCCESS booking_id=" + id + " (seat 2 reserved on trip 1)"); refreshAll(); }
    catch (e) { log("→ ORA-20001: " + e); } log("END;"); }
  if (which === "revenue") { out.textContent = "SELECT fn_revenue_period('2026-01-01','2026-01-31') FROM DUAL;";
    const s = O.payments.filter(p => p.status === "Paid").reduce((a, p) => a + p.amt, 0); log("→ Rs " + s.toLocaleString() + " (" + O.payments.length + " rows)"); }
  if (which === "trip_rev") { out.textContent = "SELECT fn_trip_revenue(trip_id=1) FROM DUAL;";
    const s = O.bookings.filter(b => b.trip === 1 && b.status === "Confirmed").reduce((a, b) => a + b.fare, 0); log("→ trip 1 revenue = Rs " + s); }
  if (which === "trig_fare") { out.textContent = "INSERT INTO BOOKING … Fare=-50;  -- trg_booking_fare_check";
    log("→ ORA-20101: Fare cannot be negative. (trigger blocked it)"); }
  if (which === "trig_dup") { out.textContent = "INSERT INTO BOOKING … (TripID=1, Seat=1);  -- UQ_BOOKING_SEAT";
    log("→ ORA-20001: seat already booked. (unique constraint + procedure guard)"); }
  if (which === "cursor") { out.textContent = "CURSOR c IS SELECT route, COUNT(*) …; -- bookings per route";
    O.routes.slice(0, 8).forEach(r => { const n = O.bookings.filter(b => { const t = O.trips.find(x => x.id === b.trip); return t && t.route === r.id; }).length; log("FETCH → " + r.from + " → " + r.to + " : " + n + " booking(s)"); }); log("CLOSE c;"); }
}
window.renderSeatAvail = renderSeatAvail;    window.doBook = doBook; window.doPay = doPay; window.doFb = doFb; window.addVehicle = addVehicle; window.addDriver = addDriver; window.addRoute = addRoute; window.addPassenger = addPassenger; window.addTrip = addTrip; window.addMaint = addMaint; window.addAnn = addAnn; window.delRow = delRow; window.editRow = editRow; window.cancelBooking = cancelBooking; window.cycleMaint = cycleMaint; window.runProc = runProc;
const DB_CONFIG = { oracleDb: "XEPDB1", mongoDb: "smartmove" };
const CONNS = {
  oracle: { el: "connOracle", label: "Oracle", db: DB_CONFIG.oracleDb, ok: !!(window.SM_ORACLE && window.SM_ORACLE.vehicles && window.SM_ORACLE.vehicles.length) },
  mongo: { el: "connMongo", label: "MongoDB", db: DB_CONFIG.mongoDb, ok: !!(window.SM_MONGO && window.SM_MONGO.announcements) }
};
function renderConns() {
  for (const k in CONNS) {
    const c = CONNS[k], el = $(c.el);
    if (!el) continue;
    el.classList.toggle("bad", !c.ok);
    el.innerHTML = "<span class='dot'></span>" + esc(c.label + " (" + c.db + "): " + (c.ok ? "connected" : "connection failed"));
  }
}
["mouseover","mouseout"].forEach(ev => document.addEventListener(ev, e => {
  const ib = e.target.closest ? e.target.closest("[data-info]") : null;
  if (!ib) return;
  const t = document.getElementById(ib.getAttribute("data-info"));
  if (t) t.hidden = (ev === "mouseout");
}));
document.addEventListener("DOMContentLoaded", () => {
  renderConns();
  $("connX").addEventListener("click", () => {
    toggleConnBar(false);
  });
  try { if (localStorage.getItem("sm_connbar") === "0") toggleConnBar(false); } catch (e) {}
  document.title = "SmartMove Transport Solutions";
  let fav = document.querySelector("link[rel=icon]");
  if (!fav) { fav = document.createElement("link"); fav.rel = "icon"; fav.type = "image/svg+xml"; fav.href = "src/logo.svg"; document.head.appendChild(fav); }
  applyLayout(); fill(); nav("dash"); renderUserChip(); syncLayoutUI(); syncConnToggle(); document.addEventListener("change",e=>{if(e.target&&e.target.name==="layoutMode")setLayout(e.target.value);});
  setTimeout(() => { if (window.authGate) window.authGate(); else document.getElementById("splash").classList.add("off"); }, 1100);
  document.querySelectorAll("#statEl").forEach(() => {});
});

let tourIdx = 0, tourTimer = null;
function tourChunk(rows, per) { const out = []; for (let i = 0; i < rows.length; i += per) out.push(rows.slice(i, i + per)); return out.length ? out : [[]]; }
function tourSlides() {
  var PER = (window.innerWidth && window.innerWidth < 700) ? 4 : 10;
  const dep = O.trips.filter(function(t){ return t.status === "Departed"; });
  const onTrip = O.drivers.filter(function(d){ return d.status === "On Trip"; });
  const S = [{ logo: true }];
  tourChunk(O.trips, PER).forEach(function(rows){ S.push({ head: "\uD83D\uDD52 Upcoming trips", body: tbl(["Trip", "Route", "Date", "Dep", "Vehicle"], rows.map(function(t){ return ["#" + t.id, esc(rName(t.route)), t.date, t.dep, esc(vName(t.vehicle))]; })) }); });
  tourChunk(O.routes, PER).forEach(function(rows){ S.push({ head: "\uD83D\uDDFA\uFE0F Routes + trip IDs", body: tbl(["Route", "KM", "Trips"], rows.map(function(r){ return [esc(r.from + " \u2192 " + r.to), r.km, O.trips.filter(function(t){ return t.route === r.id; }).map(function(t){ return "#" + t.id; }).join(" ") || "\u2014"]; })) }); });
  tourChunk(O.trips, PER).forEach(function(rows){ S.push({ head: "\uD83D\uDE8C Vehicles + available seats", body: tbl(["Trip", "Vehicle", "Free"], rows.map(function(t){ const v = O.vehicles.find(function(x){ return x.id === t.vehicle; }); const cap = v ? v.cap : 30; const tk = O.bookings.filter(function(b){ return b.trip === t.id && b.status === "Confirmed"; }).length; return ["#" + t.id, esc(vName(t.vehicle)), (cap - tk) + "/" + cap]; })) }); });
  tourChunk(dep, PER).forEach(function(rows){ S.push({ head: "\uD83D\uDEE3\uFE0F Departed vehicles", body: rows.length ? tbl(["Trip", "Vehicle", "Driver", "Status"], rows.map(function(t){ return ["#" + t.id, esc(vName(t.vehicle)), esc(dName(t.driver)), t.status]; })) : "<div class=mut>No departed vehicles</div>" }); });
  tourChunk(onTrip, PER).forEach(function(rows){ S.push({ head: "On-trip drivers", body: rows.length ? tbl(["Driver", "License", "Status"], rows.map(function(d){ return [esc(d.fn + " " + d.ln), d.lic, d.status]; })) : "<div class=mut>No drivers on trip</div>" }); });
  return S;
}
function renderTour() {
  const track = $("tourTrack");
  if (!track) return;
  const S = tourSlides();
  track.innerHTML = S.map(function(s){ return s.logo
    ? "<div class='tourSlide tourLogo'><div class=tourEnd><img src='src/logo.svg'><div class=tourTitle>Smart<span>Move</span></div><div class=mut>Transport Solutions' Updates</div></div></div>"
    : "<div class=tourSlide><h3>" + s.head + "</h3>" + s.body + "</div>"; }).join("");
  tourIdx = 0;
  tourCaps();
  tourTimer = null; ifNoActionAutomateSlide();
}
function tourCaps() { const c = $("tourCaps"), track = $("tourTrack"); if (c && track) c.textContent = (tourIdx + 1) + " / " + track.children.length; }
function tourGo(i) {
  const track = $("tourTrack");
  if (!track) return;
  const n = track.children.length;
  tourIdx = ((i % n) + n) % n;
  track.scrollTo({ left: track.children[tourIdx].offsetLeft - track.offsetLeft, behavior: "smooth" });
  tourCaps();
}
window.tourGo = tourGo;
function slideRight() { tourGo(tourIdx + 1); }
function slideLeft() { tourGo(tourIdx - 1); }
window.slideRight = slideRight; window.slideLeft = slideLeft;
let tourIdle = null;
function ifNoActionAutomateSlide() {
  if (tourIdle) clearTimeout(tourIdle);
  tourIdle = setTimeout(() => {
    if (document.querySelector("#pg-dash.on") && $("tourTrack")) tourGo(tourIdx + 1);
    ifNoActionAutomateSlide();
  }, 5000);
}
window.ifNoActionAutomateSlide = ifNoActionAutomateSlide;
function noteTourAction() {
  if (tourTimer) { clearInterval(tourTimer); tourTimer = null; }
  ifNoActionAutomateSlide();
}
let lastRC = 0;
document.addEventListener("contextmenu", e => {
  const el = e.target && e.target.closest ? e.target.closest("#tourEl") : null;
  if (!el) return;
  e.preventDefault();
  const now = Date.now();
  if (now - lastRC < 450) {
    if (tourTimer) { clearInterval(tourTimer); tourTimer = null; }
    if (tourIdle) { clearTimeout(tourIdle); tourIdle = null; }
    toast("Cover held");
  } else noteTourAction();
  lastRC = now;
});
document.addEventListener("dblclick", e => {
  const t = e.target && e.target.closest ? e.target.closest("#tourEl") : null;
  if (!t) return;
  const r = t.getBoundingClientRect();
  tourGo(tourIdx + (e.clientX < r.left + r.width / 2 ? -1 : 1));
});
document.addEventListener("pointerdown", e => { if (e.target && e.target.closest && e.target.closest("#tourEl")) { if (tourTimer) { clearInterval(tourTimer); tourTimer = null; } } });
