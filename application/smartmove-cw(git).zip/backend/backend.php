<?php
// SmartMove PHP backend reference (Member 4) - deploy under XAMPP/LAMP.
// Needs: php-oci8 + mongodb/mongodb via composer. Copy this file + .env to server.
// .env (NEVER commit): ORACLE_DSN="localhost/XEPDB1" ORACLE_USER="smartmove" ORACLE_PASS="***" MONGO_URI="mongodb://127.0.0.1:27017" MONGO_DB="smartmove"
require __DIR__.'/vendor/autoload.php';
header('Content-Type: application/json');
$env = parse_ini_file(__DIR__.'/.env');
$action = $_GET['action'] ?? $_POST['action'] ?? '';
function oracle_conn($env){ $c = oci_connect($env['ORACLE_USER'],$env['ORACLE_PASS'],$env['ORACLE_DSN']); if(!$c){ http_response_code(500); echo json_encode(['error'=>'Oracle connect failed']); exit; } return $c; }
function mongo_db($env){ return (new MongoDB\Client($env['MONGO_URI']))->selectDatabase($env['MONGO_DB']); }
try {
if($action==='dashboard'){ $c=oracle_conn($env);
  $out=[]; foreach(['VEHICLE'=>'vehicles','DRIVER'=>'drivers','ROUTE'=>'routes','PASSENGER'=>'passengers','TRIP'=>'trips','BOOKING'=>'bookings'] as $t=>$k){ $s=oci_parse($c,"SELECT COUNT(*) C FROM $t"); oci_execute($s); $r=oci_fetch_assoc($s); $out[$k]=(int)$r['C']; }
  $s=oci_parse($c,"SELECT NVL(SUM(Amount),0) R FROM PAYMENT WHERE PaymentStatus='Paid'"); oci_execute($s); $r=oci_fetch_assoc($s); $out['revenue']=(float)$r['R'];
  $mdb=mongo_db($env); $out['announcements']=iterator_to_array($mdb->announcements->find([],['sort'=>['created_at'=>-1],'limit'=>5]));
  echo json_encode($out); }
elseif($action==='book'){ // POST passenger_id,trip_id,seat,fare -> calls PL/SQL
  $c=oracle_conn($env); $stmt=oci_parse($c,"BEGIN sp_book_ticket(:p1,:p2,:p3,:p4,:bid); END;");
  oci_bind_by_name($stmt,':p1',$_POST['passenger_id']); oci_bind_by_name($stmt,':p2',$_POST['trip_id']);
  oci_bind_by_name($stmt,':p3',$_POST['seat']); oci_bind_by_name($stmt,':p4',$_POST['fare']);
  oci_bind_by_name($stmt,':bid',$bid,32,SQLT_INT);
  if(!oci_execute($stmt)){ $e=oci_error($stmt); http_response_code(400); echo json_encode(['error'=>$e['message']]); exit; }
  echo json_encode(['booking_id'=>$bid]); }
elseif($action==='feedback'){ // POST -> Oracle FEEDBACK and/or Mongo reviews (target=oracle|mongo|both, default both)
  $tgt=$_POST['target'] ?? 'both';
  if($tgt==='both'||$tgt==='oracle'){
  $c=oracle_conn($env); $stmt=oci_parse($c,"BEGIN sp_add_feedback(:p1,:p2,:r,:c); END;");
  oci_bind_by_name($stmt,':p1',$_POST['passenger_id']); oci_bind_by_name($stmt,':p2',$_POST['trip_id']);
  oci_bind_by_name($stmt,':r',$_POST['rating']); oci_bind_by_name($stmt,':c',$_POST['comment']);
  if(!oci_execute($stmt)){ $e=oci_error($stmt); http_response_code(400); echo json_encode(['error'=>$e['message']]); exit; }
  }
  if($tgt==='both'||$tgt==='mongo'){
  $mdb=mongo_db($env); $mdb->reviews->insertOne(['passenger_id'=>(int)$_POST['passenger_id'],'trip_id'=>(int)$_POST['trip_id'],'route_id'=>isset($_POST['route_id'])?(int)$_POST['route_id']:null,'rating'=>(int)$_POST['rating'],'comment'=>$_POST['comment'],'tags'=>['web'],'created_at'=>date('Y-m-d')]);
  }
  echo json_encode(['ok'=>true]); }
elseif($action==='reviews'){ $mdb=mongo_db($env); $q=[]; if(!empty($_GET['route_id'])) $q['route_id']=(int)$_GET['route_id']; if(!empty($_GET['q'])) $q['comment']=['$regex'=>$_GET['q'],'$options'=>'i'];
  echo json_encode(array_values(iterator_to_array($mdb->reviews->find($q,['sort'=>['created_at'=>-1]])))); }
else echo json_encode(['smartmove'=>1,'actions'=>['dashboard','book','feedback','reviews']]);
} catch(Throwable $e){ http_response_code(500); echo json_encode(['error'=>$e->getMessage()]); }
