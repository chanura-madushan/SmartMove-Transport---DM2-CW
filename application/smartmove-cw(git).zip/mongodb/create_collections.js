db.createCollection("vehicle_media");
db.createCollection("reviews");
db.createCollection("announcements");
db.createCollection("trip_media");
db.createCollection("users");
