// SmartMove MongoDB seed - run in mongosh after: use smartmove
db.vehicle_media.insertMany([
 {
  "vehicle_id": 1,
  "media_type": "image",
  "url": "",
  "title": "Bus front view",
  "description": "Front view of VHC1001",
  "uploaded": "2026-09-22",
  "color": "#0ea5e9"
 },
 {
  "vehicle_id": 1,
  "media_type": "document",
  "url": "",
  "title": "Insurance PDF",
  "description": "Insurance + fitness certificate",
  "uploaded": "2026-09-20",
  "color": "#8b5cf6"
 },
 {
  "vehicle_id": 6,
  "media_type": "image",
  "url": "",
  "title": "Interior",
  "description": "32-seat layout, AC",
  "uploaded": "2026-09-21",
  "color": "#10b981"
 },
 {
  "vehicle_id": 2,
  "media_type": "image",
  "url": "",
  "title": "Van side view",
  "description": "VHC1002 side profile",
  "uploaded": "2026-09-22",
  "color": "#f59e0b"
 }
]);
db.reviews.insertMany([
 {
  "passenger_id": 1,
  "trip_id": 1,
  "route_id": 1,
  "rating": 5,
  "comment": "The bus was comfortable and arrived on time.",
  "tags": [
   "comfortable",
   "on-time"
  ],
  "created": "2026-09-22"
 },
 {
  "passenger_id": 6,
  "trip_id": 6,
  "route_id": 6,
  "rating": 5,
  "comment": "Very comfortable long trip to Jaffna.",
  "tags": [
   "comfortable"
  ],
  "created": "2026-09-21"
 },
 {
  "passenger_id": 9,
  "trip_id": 9,
  "route_id": 9,
  "rating": 3,
  "comment": "Late departure, need improvement.",
  "tags": [
   "late",
   "complaint"
  ],
  "created": "2026-09-20"
 },
 {
  "passenger_id": 10,
  "trip_id": 10,
  "route_id": 10,
  "rating": 5,
  "comment": "Great service, polite driver.",
  "tags": [
   "polite",
   "clean"
  ],
  "created": "2026-09-22"
 },
 {
  "passenger_id": 14,
  "trip_id": 14,
  "route_id": 14,
  "rating": 2,
  "comment": "AC was broken, complaint about comfort.",
  "tags": [
   "complaint",
   "ac"
  ],
  "created": "2026-09-19"
 }
]);
db.announcements.insertMany([
 {
  "title": "Route 101 Delay",
  "message": "Colombo to Kandy service will depart 20 minutes late.",
  "route_id": 1,
  "priority": "high",
  "created": "2026-09-22",
  "time": "08:15"
 },
 {
  "title": "New night service",
  "message": "Colombo-Galle night bus added from Friday.",
  "route_id": 2,
  "priority": "info",
  "created": "2026-09-21",
  "time": "18:40"
 },
 {
  "title": "Maintenance notice",
  "message": "VHC1014 under brake service, replaced by VHC1011.",
  "route_id": null,
  "priority": "medium",
  "created": "2026-09-20",
  "time": "11:05"
 }
]);
db.trip_media.insertMany([
 {
  "trip_id": 1,
  "title": "Kandy scenic stop",
  "kind": "photo",
  "note": "Photo point near Peradeniya",
  "created": "2026-09-22",
  "color": "#ec4899"
 },
 {
  "trip_id": 6,
  "title": "Jaffna express guide",
  "kind": "info",
  "note": "Free water + blanket on this long trip",
  "created": "2026-09-21",
  "color": "#06b6d4"
 }
]);
