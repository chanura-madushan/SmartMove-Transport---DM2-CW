// SmartMove required MongoDB queries (mongosh, db = smartmove)
// 1. All passenger reviews for a specific route:
db.reviews.find({ route_id: 2 }).sort({ created: -1 });
// 2. Highest-rated routes:
db.reviews.aggregate([{ $group: { _id: '$route_id', avg: { $avg: '$rating' }, n: { $sum: 1 } } }, { $sort: { avg: -1 } }]);
// 3. Keyword search complaints:
db.reviews.find({ $or: [{ comment: { $regex: 'complaint|late|broken', $options: 'i' } }, { tags: 'complaint' }] });
// 4. Vehicle documents + trip media:
db.vehicle_media.find({ vehicle_id: 1 });
db.trip_media.find({ trip_id: 1 });
db.announcements.updateOne({ title: 'Route 101 Delay' }, { $set: { priority: 'medium' } });
db.reviews.deleteOne({ passenger_id: 9, trip_id: 9 });
