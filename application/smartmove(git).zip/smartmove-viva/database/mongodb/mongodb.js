// SmartMove MongoDB (Member 3) - run in mongosh
// use smartmove
// Collections used by backend.php: vehicle_media, reviews, announcements, trip_media, users.
// Field names below match exactly what backend.php writes and app.js reads.

db.vehicle_media.deleteMany({});
db.vehicle_media.insertMany([
{vehicle_id:1,media_type:"image",url:"vehicle1.jpg",title:"VHC1001 front view",description:"Front view of vehicle 1",color:"#0ea5e9",uploaded_date:"2026-09-22"},
{vehicle_id:1,media_type:"document",url:"insurance_v1.pdf",title:"Insurance certificate",description:"Insurance certificate",doc_type:"insurance",color:"#8b5cf6",uploaded_date:"2026-09-20"},
{vehicle_id:2,media_type:"image",url:"vehicle2.jpg",title:"VHC1002 side view",description:"Side view of vehicle 2",color:"#22c55e",uploaded_date:"2026-09-21"},
{vehicle_id:6,media_type:"image",url:"vehicle6_interior.jpg",title:"Interior AC layout",description:"Interior AC layout",color:"#f59e0b",uploaded_date:"2026-09-21"}]);

db.reviews.deleteMany({});
db.reviews.insertMany([
{passenger_id:10,trip_id:5,route_id:2,rating:4,comment:"The bus was comfortable and arrived on time.",tags:["comfortable","on-time"],created_at:"2026-09-22"},
{passenger_id:9,trip_id:9,route_id:9,rating:3,comment:"Late departure, need improvement.",tags:["late","complaint"],created_at:"2026-09-20"},
{passenger_id:14,trip_id:14,route_id:14,rating:2,comment:"AC broken, poor comfort.",tags:["complaint","ac"],created_at:"2026-09-19"},
{passenger_id:3,trip_id:2,route_id:2,rating:5,comment:"Excellent night service to Galle.",tags:["excellent"],created_at:"2026-09-22"}]);

db.announcements.deleteMany({});
db.announcements.insertMany([
{title:"Route 1 delay",message:"Colombo to Kandy service departs 20 min late.",route_id:1,priority:"high",created_at:"2026-09-22",time:"08:00"},
{title:"New night service",message:"Colombo-Galle night bus added.",route_id:2,priority:"info",created_at:"2026-09-21",time:"18:30"}]);

db.trip_media.deleteMany({});
db.trip_media.insertMany([
{trip_id:1,title:"Kandy scenic stop",kind:"photo",note:"Photo point near Peradeniya",created_at:"2026-09-22"}]);

// users: created only by the app (register writes {username, h, pic, since}).
// Never seed real passwords here. Optional shape check:
// db.users.findOne({username:"Kar"});

// Helpful indexes:
db.reviews.createIndex({route_id:1});
db.reviews.createIndex({comment:"text"});
db.vehicle_media.createIndex({vehicle_id:1});
db.announcements.createIndex({route_id:1});

// Required queries:
// 1. All reviews for a route: db.reviews.find({route_id:2}).sort({created_at:-1})
// 2. Highest rated route (avg): db.reviews.aggregate([{$group:{_id:"$route_id",avg:{$avg:"$rating"},n:{$sum:1}}},{$sort:{avg:-1}}])
// 3. Keyword complaint search: db.reviews.find({comment:{$regex:"complaint|late|broken",$options:"i"}})
// 4. Vehicle docs: db.vehicle_media.find({vehicle_id:1})
// Updates/deletes:
// db.announcements.updateOne({title:"Route 1 delay"},{$set:{priority:"medium"}})
// db.reviews.deleteOne({passenger_id:9,trip_id:9})
