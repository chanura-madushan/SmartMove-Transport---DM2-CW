<?php
// SmartMove PHP backend reference (Member 4) - deploy under XAMPP/LAMP.
// Needs: php-oci8 + mongodb/mongodb via composer. Copy this file + .env to server.
// .env (NEVER commit): ORACLE_DSN="localhost/XEPDB1" ORACLE_USER="smartmove" ORACLE_PASS="***" MONGO_URI="mongodb://127.0.0.1:27017" MONGO_DB="smartmove"
require __DIR__.'/vendor/autoload.php';
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') exit;
$env = is_file(__DIR__.'/.env') ? parse_ini_file(__DIR__.'/.env') : [];
$action = $_GET['action'] ?? $_POST['action'] ?? '';
function oracle_conn($env){ $c = @oci_connect($env['ORACLE_USER'] ?? '',$env['ORACLE_PASS'] ?? '',$env['ORACLE_DSN'] ?? ''); if(!$c){ $e = oci_error(); throw new Exception('Oracle connect failed: '.($e['message'] ?? '')); } return $c; }
function mongo_db($env){ return (new MongoDB\Client($env['MONGO_URI'] ?? 'mongodb://127.0.0.1:27017'))->selectDatabase($env['MONGO_DB'] ?? 'smartmove'); }
function db_names($env){ return ['oracleDb' => $env['ORACLE_DSN'] ?? 'XEPDB1', 'mongoDb' => $env['MONGO_DB'] ?? 'smartmove']; }
function oci_all($c, $sql){ $s = oci_parse($c, $sql); oci_execute($s); $rows = []; while($r = oci_fetch_assoc($s)) $rows[] = $r; return $rows; }
function q_exec($c, $sql, $bind = []){ $s = oci_parse($c, $sql); foreach($bind as $k=>$v) oci_bind_by_name($s, $k, $bind[$k]); if(!oci_execute($s, OCI_COMMIT_ON_SUCCESS)){ $e = oci_error($s); throw new Exception($e['message'] ?? 'Oracle write failed'); } return $s; }
try {
if($action==='ping'){ $n = db_names($env); $o = false; $m = false; $oe = ''; $me = '';
  try { $c = oracle_conn($env); $s = oci_parse($c,"SELECT 1 C FROM DUAL"); oci_execute($s); $o = (bool)oci_fetch_assoc($s); oci_close($c); } catch(Throwable $e){ $oe = $e->getMessage(); }
  try { $mdb = mongo_db($env); $mdb->selectCollection('announcements')->countDocuments([],['limit'=>1]); $m = true; } catch(Throwable $e){ $me = $e->getMessage(); }
  echo json_encode(['oracle_ok'=>$o,'mongo_ok'=>$m,'oracleDb'=>$n['oracleDb'],'mongoDb'=>$n['mongoDb'],'oracle_error'=>$oe,'mongo_error'=>$me]); }
elseif($action==='dashboard'){ $n = db_names($env); $c=oracle_conn($env);
  $out=[]; foreach(['VEHICLE'=>'vehicles','DRIVER'=>'drivers','ROUTE'=>'routes','PASSENGER'=>'passengers','TRIP'=>'trips','BOOKING'=>'bookings'] as $t=>$k){ $s=oci_parse($c,"SELECT COUNT(*) C FROM $t"); oci_execute($s); $r=oci_fetch_assoc($s); $out[$k]=(int)$r['C']; }
  $s=oci_parse($c,"SELECT NVL(SUM(Amount),0) R FROM PAYMENT WHERE PaymentStatus='Paid'"); oci_execute($s); $r=oci_fetch_assoc($s); $out['revenue']=(float)$r['R'];
  try { $mdb=mongo_db($env); $out['announcements']=iterator_to_array($mdb->announcements->find([],['sort'=>['created_at'=>-1],'limit'=>5])); } catch(Throwable $e){ $out['announcements']=[]; $out['mongo_error']=$e->getMessage(); }
  $out['oracleDb']=$n['oracleDb']; $out['mongoDb']=$n['mongoDb'];
  echo json_encode($out); }
elseif($action==='book'){ // POST passenger_id,trip_id,seat,fare -> calls PL/SQL
  $c=oracle_conn($env); $stmt=oci_parse($c,"BEGIN sp_book_ticket(:p1,:p2,:p3,:p4,:bid); END;");
  oci_bind_by_name($stmt,':p1',$_POST['passenger_id']); oci_bind_by_name($stmt,':p2',$_POST['trip_id']);
  oci_bind_by_name($stmt,':p3',$_POST['seat']); oci_bind_by_name($stmt,':p4',$_POST['fare']);
  oci_bind_by_name($stmt,':bid',$bid,32,SQLT_INT);
  if(!oci_execute($stmt)){ $e=oci_error($stmt); http_response_code(400); echo json_encode(['error'=>$e['message']]); exit; }
  echo json_encode(['booking_id'=>$bid]); }
elseif($action==='feedback'){ // POST -> Oracle FEEDBACK and/or Mongo reviews (target=oracle|mongo|both, default both)
  $tgt=$_POST['target'] ?? 'both';
  if($tgt==='both'||$tgt==='oracle'){
  $c=oracle_conn($env); $stmt=oci_parse($c,"BEGIN sp_add_feedback(:p1,:p2,:r,:c); END;");
  oci_bind_by_name($stmt,':p1',$_POST['passenger_id']); oci_bind_by_name($stmt,':p2',$_POST['trip_id']);
  oci_bind_by_name($stmt,':r',$_POST['rating']); oci_bind_by_name($stmt,':c',$_POST['comment']);
  if(!oci_execute($stmt)){ $e=oci_error($stmt); http_response_code(400); echo json_encode(['error'=>$e['message']]); exit; }
  }
  if($tgt==='both'||$tgt==='mongo'){
  $mdb=mongo_db($env); $mdb->reviews->insertOne(['passenger_id'=>(int)$_POST['passenger_id'],'trip_id'=>(int)$_POST['trip_id'],'route_id'=>isset($_POST['route_id'])?(int)$_POST['route_id']:null,'rating'=>(int)$_POST['rating'],'comment'=>$_POST['comment'],'tags'=>['web'],'created_at'=>date('Y-m-d')]);
  }
  echo json_encode(['ok'=>true]); }
elseif($action==='reviews'){ $mdb=mongo_db($env); $q=[]; if(!empty($_GET['route_id'])) $q['route_id']=(int)$_GET['route_id']; if(!empty($_GET['q'])) $q['comment']=['$regex'=>$_GET['q'],'$options'=>'i'];
  echo json_encode(array_values(iterator_to_array($mdb->reviews->find($q,['sort'=>['created_at'=>-1]])))); }
elseif($action==='list_all'){ $c=oracle_conn($env);
  $out = ['vehicles'=>oci_all($c,"SELECT VehicleID id, RegistrationNo reg, VehicleType type, Capacity cap, Status status FROM VEHICLE ORDER BY VehicleID"),
    'drivers'=>oci_all($c,"SELECT DriverID id, FirstName fn, LastName ln, LicenseNo lic, Phone phone, Status status FROM DRIVER ORDER BY DriverID"),
    'routes'=>oci_all($c,"SELECT RouteID id, StartLocation \"from\", EndLocation \"to\", Distance km, Status status FROM ROUTE ORDER BY RouteID"),
    'passengers'=>oci_all($c,"SELECT PassengerID id, FirstName fn, LastName ln, Phone phone, Email email FROM PASSENGER ORDER BY PassengerID"),
    'trips'=>oci_all($c,"SELECT TripID id, VehicleID vehicle, DriverID driver, RouteID route, TO_CHAR(TripDate,'YYYY-MM-DD') \"date\", DepTime dep, ArrTime arr, Status status FROM TRIP ORDER BY TripID"),
    'bookings'=>oci_all($c,"SELECT BookingID id, PassengerID pass, TripID trip, TO_CHAR(BookingDate,'YYYY-MM-DD') \"date\", SeatNumber seat, Fare fare, BookingStatus status FROM BOOKING ORDER BY BookingID"),
    'payments'=>oci_all($c,"SELECT PaymentID id, BookingID booking, TO_CHAR(PaymentDate,'YYYY-MM-DD') \"date\", Amount amt, PaymentMethod method, PaymentStatus status FROM PAYMENT ORDER BY PaymentID"),
    'maintenance'=>oci_all($c,"SELECT MaintenanceID id, VehicleID vehicle, TO_CHAR(MaintenanceDate,'YYYY-MM-DD') \"date\", TO_CHAR(NextMaintenanceDate,'YYYY-MM-DD') next, MaintenanceType type, Description \"desc\", Cost cost, MaintenanceStatus status FROM MAINTENANCE ORDER BY MaintenanceID"),
    'feedback'=>oci_all($c,"SELECT FeedbackID id, PassengerID pass, TripID trip, Rating rating, CommentText text, TO_CHAR(CreatedDate,'YYYY-MM-DD') \"date\" FROM FEEDBACK ORDER BY FeedbackID")];
  try { $mdb=mongo_db($env); $out['announcements']=array_values(iterator_to_array($mdb->announcements->find([],['sort'=>['created_at'=>-1]]))); $out['reviews']=array_values(iterator_to_array($mdb->reviews->find([],['sort'=>['created_at'=>-1]]))); $out['vehicle_media']=array_values(iterator_to_array($mdb->vehicle_media->find([]))); $out['trip_media']=array_values(iterator_to_array($mdb->trip_media->find([]))); } catch(Throwable $e){ $out['announcements']=[]; $out['reviews']=[]; $out['vehicle_media']=[]; $out['trip_media']=[]; $out['mongo_error']=$e->getMessage(); }
  echo json_encode($out); }
elseif($action==='add'){ $t = $_POST['table'] ?? ''; $c=oracle_conn($env); $mdb=null;
  if($t==='vehicle'){ q_exec($c,"INSERT INTO VEHICLE(RegistrationNo,VehicleType,Capacity,Status) VALUES(:r,:y,:p,:s)",[':r'=>$_POST['reg'],':y'=>$_POST['type'],':p'=>(int)$_POST['cap'],':s'=>$_POST['status']]); }
  elseif($t==='driver'){ q_exec($c,"INSERT INTO DRIVER(FirstName,LastName,LicenseNo,Phone,Status) VALUES(:a,:b,:c,:d,:e)",[':a'=>$_POST['fn'],':b'=>$_POST['ln'],':c'=>$_POST['lic'],':d'=>$_POST['phone'],':e'=>$_POST['status']]); }
  elseif($t==='route'){ q_exec($c,"INSERT INTO ROUTE(StartLocation,EndLocation,Distance,Status) VALUES(:a,:b,:k,:s)",[':a'=>$_POST['from'],':b'=>$_POST['to'],':k'=>(float)$_POST['km'],':s'=>$_POST['status']]); }
  elseif($t==='passenger'){ q_exec($c,"INSERT INTO PASSENGER(FirstName,LastName,Phone,Email) VALUES(:a,:b,:p,:e)",[':a'=>$_POST['fn'],':b'=>$_POST['ln'],':p'=>$_POST['phone'],':e'=>($_POST['email'] ?: null)]); }
  elseif($t==='trip'){ q_exec($c,"INSERT INTO TRIP(VehicleID,DriverID,RouteID,TripDate,DepTime,Status) VALUES(:v,:d,:r,TO_DATE(:t,'YYYY-MM-DD'),:p,:s)",[':v'=>(int)$_POST['vehicle'],':d'=>(int)$_POST['driver'],':r'=>(int)$_POST['route'],':t'=>$_POST['date'],':p'=>$_POST['dep'],':s'=>$_POST['status'] ?? 'Scheduled']); }
  elseif($t==='maintenance'){ q_exec($c,"INSERT INTO MAINTENANCE(VehicleID,MaintenanceDate,NextMaintenanceDate,MaintenanceType,Cost,MaintenanceStatus) VALUES(:v,TO_DATE(:d,'YYYY-MM-DD'),TO_DATE(:n,'YYYY-MM-DD'),:y,:c,'Scheduled')",[':v'=>(int)$_POST['vehicle'],':d'=>$_POST['date'],':n'=>$_POST['next'],':y'=>$_POST['type'],':c'=>(float)$_POST['cost']]); }
  elseif($t==='pay'){ $stmt=oci_parse($c,"BEGIN sp_record_payment(:b,:a,:m); END;"); oci_bind_by_name($stmt,':b',$_POST['booking']); oci_bind_by_name($stmt,':a',$_POST['amt']); oci_bind_by_name($stmt,':m',$_POST['method']); if(!oci_execute($stmt)){ $e=oci_error($stmt); throw new Exception($e['message']); } }
  elseif($t==='announcement'){ $mdb=mongo_db($env); $mdb->announcements->insertOne(['title'=>$_POST['title'],'message'=>$_POST['message'],'route_id'=>null,'priority'=>$_POST['priority'] ?? 'info','created_at'=>date('Y-m-d'),'time'=>date('H:i')]); }
  else { http_response_code(400); echo json_encode(['error'=>'unknown table']); exit; }
  echo json_encode(['ok'=>true]); }
elseif($action==='modify'){ $t = $_POST['op'] ?? ''; $c=oracle_conn($env);
  if($t==='cancel_booking'){ q_exec($c,"UPDATE BOOKING SET BookingStatus='Cancelled' WHERE BookingID=:i",[':i'=>(int)$_POST['id']]); }
  elseif($t==='cycle_vehicle'){ q_exec($c,"UPDATE VEHICLE SET Status=:s WHERE VehicleID=:i",[':s'=>$_POST['status'],':i'=>(int)$_POST['id']]); }
  elseif($t==='cycle_maint'){ q_exec($c,"UPDATE MAINTENANCE SET MaintenanceStatus=:s WHERE MaintenanceID=:i",[':s'=>$_POST['status'],':i'=>(int)$_POST['id']]); }
  elseif($t==='edit_vehicle'){ q_exec($c,"UPDATE VEHICLE SET Status=:s WHERE VehicleID=:i",[':s'=>$_POST['status'],':i'=>(int)$_POST['id']]); }
  elseif($t==='edit_driver'){ q_exec($c,"UPDATE DRIVER SET Phone=:p, Status=:s WHERE DriverID=:i",[':p'=>$_POST['phone'],':s'=>$_POST['status'],':i'=>(int)$_POST['id']]); }
  elseif($t==='edit_route'){ q_exec($c,"UPDATE ROUTE SET Distance=:k, Status=:s WHERE RouteID=:i",[':k'=>(float)$_POST['km'],':s'=>$_POST['status'],':i'=>(int)$_POST['id']]); }
  elseif($t==='edit_passenger'){ q_exec($c,"UPDATE PASSENGER SET Phone=:p, Email=:e WHERE PassengerID=:i",[':p'=>$_POST['phone'],':e'=>($_POST['email'] ?: null),':i'=>(int)$_POST['id']]); }
  elseif($t==='delete'){ $k=$_POST['kind'] ?? ''; $id=(int)$_POST['id'];
    $map=['vehicle'=>"DELETE FROM VEHICLE WHERE VehicleID=:i",'driver'=>"DELETE FROM DRIVER WHERE DriverID=:i",'route'=>"DELETE FROM ROUTE WHERE RouteID=:i",'passenger'=>"DELETE FROM PASSENGER WHERE PassengerID=:i",'trip'=>"DELETE FROM TRIP WHERE TripID=:i",'maint'=>"DELETE FROM MAINTENANCE WHERE MaintenanceID=:i"];
    if(!isset($map[$k])){ http_response_code(400); echo json_encode(['error'=>'unknown kind']); exit; }
    q_exec($c,$map[$k],[':i'=>$id]); }
  elseif($t==='del_announcement'){ $mdb=mongo_db($env); $mdb->announcements->deleteOne(['title'=>$_POST['title']]); }
  else { http_response_code(400); echo json_encode(['error'=>'unknown op']); exit; }
  echo json_encode(['ok'=>true]); }
elseif($action==='users'){ $op = $_POST['op'] ?? ''; $mdb=mongo_db($env); $col=$mdb->users;
  if($op==='register'){ $u=$_POST['username'] ?? ''; if(!preg_match('/^[A-Za-z0-9_]{3,16}$/',$u)){ http_response_code(400); echo json_encode(['error'=>'bad username']); exit; }
    if($col->countDocuments(['username'=>$u])>0){ http_response_code(400); echo json_encode(['error'=>'username taken']); exit; }
    $col->insertOne(['username'=>$u,'h'=>$_POST['h'] ?? '','pic'=>$_POST['pic'] ?? '','since'=>date('Y-m-d')]); echo json_encode(['ok'=>true]); }
  elseif($op==='login'){ $d=$col->findOne(['username'=>$_POST['username'] ?? '']); if(!$d || ($d['h'] ?? '')!==($_POST['h'] ?? '')){ http_response_code(401); echo json_encode(['error'=>'invalid login']); exit; } echo json_encode(['ok'=>true,'username'=>$d['username'],'pic'=>$d['pic'] ?? '','since'=>$d['since'] ?? '']); }
  elseif($op==='get'){ $d=$col->findOne(['username'=>$_POST['username'] ?? '']); echo json_encode($d ? ['username'=>$d['username'],'pic'=>$d['pic'] ?? '','since'=>$d['since'] ?? ''] : ['error'=>'not found']); }
  elseif($op==='set_pic'){ $col->updateOne(['username'=>$_POST['username'] ?? ''],['$set'=>['pic'=>$_POST['pic'] ?? '']]); echo json_encode(['ok'=>true]); }
  elseif($op==='set_pass'){ $col->updateOne(['username'=>$_POST['username'] ?? ''],['$set'=>['h'=>$_POST['h'] ?? '']]); echo json_encode(['ok'=>true]); }
  elseif($op==='verify'){ $d=$col->findOne(['username'=>$_POST['username'] ?? '']); if(!$d || ($d['h'] ?? '')!==($_POST['h'] ?? '')){ http_response_code(401); echo json_encode(['error'=>'wrong password']); exit; } echo json_encode(['ok'=>true]); }
  elseif($op==='reset_issue'){ $u=$_POST['username'] ?? ''; $d=$col->findOne(['username'=>$u]); if(!$d){ http_response_code(404); echo json_encode(['error'=>'no account with that username']); exit; }
    $code=strval(random_int(100000,999999)); $col->updateOne(['username'=>$u],['$set'=>['resetCode'=>$code,'resetExp'=>time()+600]]); echo json_encode(['ok'=>true,'code'=>$code]); }
  elseif($op==='reset_verify'){ $d=$col->findOne(['username'=>$_POST['username'] ?? '']); if(!$d || ($d['resetCode'] ?? '')!==($_POST['code'] ?? '') || time()>(int)($d['resetExp'] ?? 0)){ http_response_code(400); echo json_encode(['error'=>'wrong or expired code']); exit; } echo json_encode(['ok'=>true]); }
  elseif($op==='reset_reset'){ $d=$col->findOne(['username'=>$_POST['username'] ?? '']); if(!$d || ($d['resetCode'] ?? '')!==($_POST['code'] ?? '') || time()>(int)($d['resetExp'] ?? 0)){ http_response_code(400); echo json_encode(['error'=>'wrong or expired code']); exit; }
    $col->updateOne(['username'=>$_POST['username']],['$set'=>['h'=>$_POST['h'] ?? ''],'$unset'=>['resetCode'=>'','resetExp'=>'']]); echo json_encode(['ok'=>true]); }
  elseif($op==='delete'){ $col->deleteOne(['username'=>$_POST['username'] ?? '']); echo json_encode(['ok'=>true]); }
  elseif($op==='list'){ $out=[]; foreach($col->find([],['sort'=>['username'=>1],'limit'=>50]) as $d) $out[]=['username'=>$d['username'],'pic'=>$d['pic'] ?? '','since'=>$d['since'] ?? '']; echo json_encode($out); }
  else { http_response_code(400); echo json_encode(['error'=>'unknown op']); } }
elseif($action==='plsql'){ $probe=$_POST['probe'] ?? $_GET['probe'] ?? ''; $c=oracle_conn($env);
  $tryWrite = function($sql, $bind = []) use ($c) {
    $st = oci_parse($c, $sql); foreach($bind as $k=>$v) oci_bind_by_name($st, $k, $bind[$k]);
    $ok = @oci_execute($st, OCI_DEFAULT); $e = oci_error($st); @oci_rollback($c);
    return ['ok' => $ok, 'error' => $ok ? '' : ($e['message'] ?? 'blocked')];
  };
  if($probe==='neg_fare'){ $r=$tryWrite("INSERT INTO BOOKING(PassengerID,TripID,SeatNumber,Fare,BookingStatus) SELECT MIN(PassengerID),MIN(TripID),99999,-50,'X' FROM PASSENGER,TRIP"); echo json_encode(['sql'=>'INSERT INTO BOOKING ... Fare=-50','blocked'=>!$r['ok'],'error'=>$r['error']]); }
  elseif($probe==='dup_seat'){ $one=oci_all($c,"SELECT TripID t, SeatNumber s FROM BOOKING WHERE BookingStatus='Confirmed' AND ROWNUM=1"); if(!$one){ echo json_encode(['error'=>'no confirmed booking to duplicate']); exit; }
    $r=$tryWrite("INSERT INTO BOOKING(PassengerID,TripID,SeatNumber,Fare,BookingStatus) VALUES(1,:t,:s,250,'Confirmed')",[':t'=>$one[0]['T'],':s'=>$one[0]['S']]); echo json_encode(['sql'=>'INSERT INTO BOOKING ... (TripID='.$one[0]['T'].', Seat='.$one[0]['S'].')','blocked'=>!$r['ok'],'error'=>$r['error']]); }
  elseif($probe==='neg_amount'){ $one=oci_all($c,"SELECT PaymentID p FROM PAYMENT WHERE ROWNUM=1"); if(!$one){ echo json_encode(['error'=>'no payment row yet']); exit; }
    $r=$tryWrite("UPDATE PAYMENT SET Amount=-100 WHERE PaymentID=:i",[':i'=>$one[0]['P']]); echo json_encode(['sql'=>'UPDATE PAYMENT SET Amount=-100','blocked'=>!$r['ok'],'error'=>$r['error']]); }
  elseif($probe==='bad_rating'){ $one=oci_all($c,"SELECT FeedbackID f FROM FEEDBACK WHERE ROWNUM=1"); if(!$one){ echo json_encode(['error'=>'no feedback row yet']); exit; }
    $r=$tryWrite("UPDATE FEEDBACK SET Rating=6 WHERE FeedbackID=:i",[':i'=>$one[0]['F']]); echo json_encode(['sql'=>'UPDATE FEEDBACK SET Rating=6','blocked'=>!$r['ok'],'error'=>$r['error']]); }
  elseif($probe==='bad_dates'){ $r=$tryWrite("INSERT INTO MAINTENANCE(VehicleID,MaintenanceDate,NextMaintenanceDate,MaintenanceType) SELECT MIN(VehicleID),DATE'2026-05-01',DATE'2026-02-01','General Service' FROM VEHICLE"); echo json_encode(['sql'=>'INSERT INTO MAINTENANCE ... (next < date)','blocked'=>!$r['ok'],'error'=>$r['error']]); }
  elseif($probe==='del_route'){ $one=oci_all($c,"SELECT RouteID r FROM ROUTE WHERE RouteID IN (SELECT RouteID FROM TRIP) AND ROWNUM=1"); if(!$one){ echo json_encode(['error'=>'no route with trips']); exit; }
    $r=$tryWrite("DELETE FROM ROUTE WHERE RouteID=:i",[':i'=>$one[0]['R']]); echo json_encode(['sql'=>'DELETE FROM ROUTE WHERE RouteID='.$one[0]['R'],'blocked'=>!$r['ok'],'error'=>$r['error']]); }
  elseif($probe==='fn'){ $fn=$_POST['fn'] ?? ''; $args=$_POST['args'] ?? '';
    $allow=['fn_trip_revenue'=>1,'fn_revenue_period'=>2,'fn_route_revenue'=>1,'fn_passenger_total_spent'=>1,'fn_driver_avg_rating'=>1,'fn_overdue_count'=>0];
    if(!isset($allow[$fn])){ http_response_code(400); echo json_encode(['error'=>'unknown function']); exit; }
    $ph=[]; for($i=1;$i<=$allow[$fn];$i++) $ph[]=":a$i";
    $sql="SELECT $fn(".implode(',',$ph).") V FROM DUAL"; $st=oci_parse($c,$sql);
    if($fn==='fn_revenue_period'){ $sql="SELECT fn_revenue_period(TO_DATE(:a1,'YYYY-MM-DD'),TO_DATE(:a2,'YYYY-MM-DD')) V FROM DUAL"; $st=oci_parse($c,$sql); $a=explode(',', $args); oci_bind_by_name($st,':a1',$a[0]); oci_bind_by_name($st,':a2',$a[1]); }
    elseif($allow[$fn]===1){ oci_bind_by_name($st,':a1',$args); }
    oci_execute($st); $row=oci_fetch_assoc($st); echo json_encode(['sql'=>$sql,'value'=>$row ? array_values($row)[0] : null]); }
  elseif($probe==='cursor'){ $q=$_POST['q'] ?? '';
    if($q==='routes'){ $rows=oci_all($c,"SELECT r.StartLocation||' - '||r.EndLocation route, COUNT(b.BookingID) bookings, NVL(SUM(b.Fare),0) revenue FROM ROUTE r LEFT JOIN TRIP t ON t.RouteID=r.RouteID LEFT JOIN BOOKING b ON b.TripID=t.TripID AND b.BookingStatus='Confirmed' GROUP BY r.RouteID,r.StartLocation,r.EndLocation ORDER BY bookings DESC"); echo json_encode(['sql'=>'CURSOR c IS SELECT route, COUNT(*), SUM(Fare) ...','rows'=>$rows]); }
    elseif($q==='paymethod'){ $rows=oci_all($c,"SELECT PaymentMethod m, COUNT(*) n, SUM(Amount) total FROM PAYMENT WHERE PaymentStatus='Paid' GROUP BY PaymentMethod"); echo json_encode(['sql'=>'CURSOR c IS SELECT PaymentMethod, COUNT(*), SUM(Amount) ...','rows'=>$rows]); }
    elseif($q==='due'){ $rows=oci_all($c,"SELECT v.RegistrationNo vehicle, TO_CHAR(m.NextMaintenanceDate,'YYYY-MM-DD') next, m.MaintenanceType type, m.MaintenanceStatus status FROM MAINTENANCE m JOIN VEHICLE v ON v.VehicleID=m.VehicleID WHERE m.NextMaintenanceDate <= SYSDATE+30 ORDER BY m.NextMaintenanceDate"); echo json_encode(['sql'=>'CURSOR c IS SELECT * FROM MAINTENANCE WHERE NextDate <= SYSDATE+30 ...','rows'=>$rows]); }
    elseif($q==='drivers'){ $rows=oci_all($c,"SELECT d.FirstName||' '||d.LastName driver, COUNT(t.TripID) trips, NVL(AVG(f.Rating),0) avg_rating FROM DRIVER d LEFT JOIN TRIP t ON t.DriverID=d.DriverID LEFT JOIN FEEDBACK f ON f.TripID=t.TripID GROUP BY d.DriverID,d.FirstName,d.LastName ORDER BY trips DESC"); echo json_encode(['sql'=>'CURSOR c IS SELECT driver, COUNT(*), AVG(rating) ...','rows'=>$rows]); }
    elseif($q==='passbook'){ $pid=(int)($_POST['pid'] ?? 0); $rows=oci_all($c,"SELECT BookingID id, TripID trip, SeatNumber seat, Fare fare, BookingStatus status FROM BOOKING WHERE PassengerID=$pid ORDER BY BookingID"); echo json_encode(['sql'=>'CURSOR c IS SELECT * FROM BOOKING WHERE PassengerID='.$pid.' ...','rows'=>$rows]); }
    else { http_response_code(400); echo json_encode(['error'=>'unknown cursor']); } }
  else { http_response_code(400); echo json_encode(['error'=>'unknown action']); } }
else echo json_encode(['smartmove'=>1,'actions'=>['ping','dashboard','list_all','add','modify','users','plsql','book','feedback','reviews']]);
} catch(Throwable $e){ http_response_code(500); echo json_encode(['error'=>$e->getMessage()]); }
